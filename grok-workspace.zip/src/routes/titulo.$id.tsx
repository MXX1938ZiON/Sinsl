import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Play, Star } from "lucide-react";
import { useEffect, useState } from "react";
import { GENRES, RATINGS, type CatalogTitle } from "@/lib/sinal/catalog";
import { getTitle, rateTitle } from "@/lib/sinal/fns";
import { useCurrentUserState } from "@/lib/auth/use-current-user";

export const Route = createFileRoute("/titulo/$id")({ component: TitlePage });

function TitlePage() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const { user } = useCurrentUserState();
  const [item, setItem] = useState<CatalogTitle | null | undefined>(undefined);

  useEffect(() => {
    void getTitle({ data: id }).then(setItem);
  }, [id]);

  if (item === undefined) return <div className="h-80 animate-pulse bg-surface" />;
  if (!item) {
    return (
      <main className="px-6 py-10">
        <p>Título não encontrado.</p>
      </main>
    );
  }

  const rating = item.ageRating ? RATINGS[item.ageRating] : null;

  function play() {
    if (item!.locked) void navigate({ to: "/conta" });
    else void navigate({ to: "/player/$id", params: { id: item!.id } });
  }

  return (
    <main className="pb-16">
      <div className="px-6 pt-6 sm:px-10">
        <Link to="/" className="text-sm text-muted hover:text-fg">
          ← início
        </Link>
      </div>
      <div className="flex flex-wrap gap-8 px-6 py-6 sm:px-10">
        <div className="relative flex aspect-2/3 w-60 items-end overflow-hidden rounded-md border border-border bg-surface p-4 font-display">
          {item.poster ? <img src={item.poster} alt="" className="absolute inset-0 h-full w-full object-cover" /> : <span>{item.title}</span>}
        </div>
        <div className="flex min-w-64 flex-1 flex-col gap-3.5">
          <h1 className="font-display text-3xl font-semibold">{item.title}</h1>
          <p className="max-w-xl text-sm leading-relaxed">{item.synopsis}</p>
          <div className="flex flex-wrap gap-2">
            {item.genres.map((g) => (
              <span key={g} className="rounded-full border border-border bg-surface px-3.5 py-1.5 text-xs text-muted">
                {GENRES.find((x) => x.key === g)?.label ?? g}
              </span>
            ))}
            <span className="rounded-full border border-border bg-surface px-3.5 py-1.5 text-xs text-muted">
              {item.source === "iptv" ? "IPTV" : item.source === "telegram" ? "Telegram" : item.source === "youtube" ? "YouTube" : "P2P"}
            </span>
          </div>
          <div>
            {rating ? (
              <span className={`inline-flex rounded-full px-3.5 py-1.5 text-xs font-semibold ${rating.colorClass}`}>
                {rating.label}
              </span>
            ) : (
              <span className="text-xs text-muted">classificação não definida</span>
            )}
          </div>
          <Stars item={item} canRate={Boolean(user)} onRated={() => void getTitle({ data: id }).then(setItem)} />
          {item.hasStream ? (
            <button
              type="button"
              onClick={play}
              className="flex items-center gap-2 self-start rounded-md bg-signal px-6 py-3 text-sm font-semibold text-bg"
            >
              <Play className="size-4 fill-current" /> Assistir
            </button>
          ) : (
            <p className="text-sm text-muted">Sem arquivo cadastrado</p>
          )}
        </div>
      </div>
      {item.posterCredit ? <p className="px-6 text-[10px] text-muted sm:px-10">{item.posterCredit}</p> : null}
    </main>
  );
}

function Stars({
  item,
  canRate,
  onRated,
}: {
  item: CatalogTitle;
  canRate: boolean;
  onRated: () => void;
}) {
  return (
    <div className="flex items-center gap-2.5">
      <div className="flex gap-0.5">
        {[1, 2, 3, 4, 5].map((n) => (
          <button
            key={n}
            type="button"
            disabled={!canRate}
            onClick={() => void rateTitle({ data: { titleId: item.id, stars: n } }).then(onRated)}
            className={(item.myRating ?? Math.round(item.avgRating ?? 0)) >= n ? "text-signal" : "text-border"}
            aria-label={`${n} estrelas`}
          >
            <Star className="size-5 fill-current" />
          </button>
        ))}
      </div>
      <span className="text-xs text-muted">
        {item.ratingCount ? `${item.avgRating?.toFixed(1)} · ${item.ratingCount}` : "ainda sem notas"}
      </span>
    </div>
  );
}
