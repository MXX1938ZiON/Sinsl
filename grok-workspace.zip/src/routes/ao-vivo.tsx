import { createFileRoute, Link } from "@tanstack/react-router";
import { Radio } from "lucide-react";
import { useEffect, useState } from "react";
import type { CatalogTitle } from "@/lib/sinal/catalog";
import { listCatalog } from "@/lib/sinal/fns";
import { PosterCard } from "@/components/sinal/poster-card";

export const Route = createFileRoute("/ao-vivo")({ component: LivePage });

function LivePage() {
  const [items, setItems] = useState<CatalogTitle[]>([]);
  useEffect(() => {
    void listCatalog().then((all) =>
      setItems(all.filter((i) => i.source === "iptv" || i.category === "ao-vivo")),
    );
  }, []);

  return (
    <main className="pb-16">
      <div className="flex items-center gap-3 px-6 pt-7 sm:px-10">
        <Radio className="size-5 text-live" />
        <h1 className="font-display text-2xl font-semibold">Ao vivo</h1>
      </div>
      <p className="mt-1 max-w-xl px-6 text-sm leading-relaxed text-muted sm:px-10">
        Canais IPTV em HLS. O admin cola uma URL m3u8 ou importa uma lista M3U.
        Só entram streams que vocês hospedam ou têm direito de distribuir.
      </p>
      <div className="grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-4 px-6 py-6 sm:px-10">
        {items.map((it) => (
          <PosterCard key={it.id} item={it} />
        ))}
      </div>
      {!items.length ? (
        <p className="px-6 text-sm text-muted sm:px-10">
          Nenhum canal ainda.{" "}
          <Link to="/" className="text-signal underline">
            Voltar ao início
          </Link>
        </p>
      ) : null}
    </main>
  );
}
