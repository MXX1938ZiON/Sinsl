import { createFileRoute, Link } from "@tanstack/react-router";
import { COLLECTIONS } from "@/lib/sinal/catalog";

export const Route = createFileRoute("/colecao/$key")({ component: CollectionPage });

function CollectionPage() {
  const { key } = Route.useParams();
  const col = COLLECTIONS.find((c) => c.key === key);
  if (!col) {
    return (
      <main className="px-6 py-10">
        <p>Coleção não encontrada.</p>
      </main>
    );
  }
  return (
    <main className="pb-16">
      <div className="flex items-center gap-4 px-6 pt-7 sm:px-10">
        <Link to="/" className="text-sm text-muted hover:text-fg">
          ← início
        </Link>
        <h1 className="font-display text-2xl font-semibold">{col.title}</h1>
      </div>
      <p className="mt-1 px-6 text-sm text-muted sm:px-10">{col.sub}</p>
      <section className="px-6 pt-6 sm:px-10">
        <h3 className="font-display text-base font-semibold">Principal</h3>
        <Grid items={col.items} />
        {col.spinoffs.map((s) => (
          <div key={s.key} className="mt-8">
            <h3 className="font-display text-base font-semibold">{s.title}</h3>
            <p className="mb-3 text-xs text-muted">{s.sub}</p>
            <Grid items={s.items} />
          </div>
        ))}
      </section>
    </main>
  );
}

function Grid({ items }: { items: { title: string; desc: string }[] }) {
  return (
    <div className="mt-3 grid grid-cols-[repeat(auto-fill,minmax(130px,1fr))] gap-3.5">
      {items.map((it) => (
        <article key={it.title} className="overflow-hidden rounded-md border border-border bg-surface">
          <div className="flex aspect-2/3 items-end bg-surface-hover p-2 text-xs text-muted">{it.title}</div>
          <p className="p-2.5 text-[10.5px] leading-snug text-muted">{it.desc}</p>
        </article>
      ))}
    </div>
  );
}
