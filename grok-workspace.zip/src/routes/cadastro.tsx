import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useRef, useState, type FormEvent } from "react";
import { authClient } from "@/lib/auth/client";
import { SignalChallenge, type ChallengeValue } from "@/components/sinal/signal-challenge";
import { claimSignupTicket, getPublicConfig, prepareSignup } from "@/lib/sinal/fns";

export const Route = createFileRoute("/cadastro")({ component: Cadastro });

function Cadastro() {
  const navigate = useNavigate();
  const startedAt = useRef(Date.now());
  const [mode, setMode] = useState<"challenge" | "invite_only" | "closed">("challenge");
  const [username, setUsername] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [password2, setPassword2] = useState("");
  const [invite, setInvite] = useState("");
  const [honeypot, setHoneypot] = useState("");
  const [challenge, setChallenge] = useState<ChallengeValue | null>(null);
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    void getPublicConfig().then((c) => setMode(c.signupMode));
  }, []);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    if (password !== password2) {
      setError("as senhas não coincidem");
      return;
    }
    if (password.length < 6) {
      setError("senha com pelo menos 6 caracteres");
      return;
    }
    if (!challenge) {
      setError("complete a prova de sinal");
      return;
    }
    setBusy(true);
    try {
      const { ticket } = await prepareSignup({
        data: {
          honeypot,
          startedAt: startedAt.current,
          challengeId: challenge.challengeId,
          taps: challenge.taps,
          inviteCode: invite,
        },
      });
      const { error: err } = await authClient.signUp.email({
        email,
        password,
        name: username,
      });
      if (err) throw new Error(err.message ?? "não foi possível criar a conta");
      await claimSignupTicket({ data: { ticket, username } });
      await navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "falha no cadastro");
    } finally {
      setBusy(false);
    }
  }

  if (mode === "closed") {
    return (
      <main className="px-6 py-16 text-center">
        <h1 className="font-display text-2xl font-semibold">Cadastro fechado</h1>
        <p className="mt-2 text-muted">O admin travou novas contas contra spam. Peça um convite.</p>
      </main>
    );
  }

  return (
    <main className="mx-auto grid max-w-4xl gap-10 px-5 py-10 md:grid-cols-2">
      <div>
        <h1 className="font-display text-2xl font-semibold leading-snug">
          Cadastro livre, assistir com assinatura.
        </h1>
        <p className="mt-3 text-sm leading-relaxed text-muted">
          Qualquer um cria conta. O spam para na prova de sinal, no limite por IP e no
          convite quando o admin fecha a porta. Assistir — P2P, IPTV, YouTube ou Telegram —
          pede 30 dias ativos.
        </p>
        <ul className="mt-5 space-y-2.5 text-sm">
          {[
            "Catálogo navegável sem pagar",
            "Player P2P no navegador, servidor leve",
            "Canais ao vivo (IPTV / HLS)",
            "Posts do Telegram no player do Sinal",
            "Trava contra cadastro automático",
          ].map((t) => (
            <li key={t} className="relative pl-5 before:absolute before:left-0 before:text-live before:content-['✓']">
              {t}
            </li>
          ))}
        </ul>
      </div>
      <form className="relative flex flex-col gap-2.5 rounded-lg border border-border bg-surface p-6" onSubmit={onSubmit}>
        <input
          className="honeypot"
          tabIndex={-1}
          autoComplete="off"
          aria-hidden="true"
          value={honeypot}
          onChange={(e) => setHoneypot(e.target.value)}
        />
        <input
          required
          minLength={3}
          placeholder="usuário"
          className="rounded-md border border-border bg-bg px-3 py-2.5 text-sm"
          value={username}
          onChange={(e) => setUsername(e.target.value)}
        />
        <input
          type="email"
          required
          placeholder="e-mail"
          className="rounded-md border border-border bg-bg px-3 py-2.5 text-sm"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
        />
        <input
          type="password"
          required
          placeholder="senha"
          className="rounded-md border border-border bg-bg px-3 py-2.5 text-sm"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
        />
        <input
          type="password"
          required
          placeholder="confirmar senha"
          className="rounded-md border border-border bg-bg px-3 py-2.5 text-sm"
          value={password2}
          onChange={(e) => setPassword2(e.target.value)}
        />
        <input
          placeholder={mode === "invite_only" ? "convite (obrigatório)" : "convite (opcional)"}
          required={mode === "invite_only"}
          className="rounded-md border border-border bg-bg px-3 py-2.5 text-sm"
          value={invite}
          onChange={(e) => setInvite(e.target.value)}
        />
        <SignalChallenge onChange={setChallenge} />
        {error ? <p className="text-xs text-danger">{error}</p> : null}
        <button
          type="submit"
          disabled={busy}
          className="rounded-md bg-signal py-2.5 text-sm font-medium text-bg disabled:opacity-60"
        >
          {busy ? "criando…" : "Criar conta"}
        </button>
        <p className="text-sm text-muted">
          Já tem conta?{" "}
          <Link to="/login" className="text-signal underline">
            Login
          </Link>
        </p>
      </form>
    </main>
  );
}
