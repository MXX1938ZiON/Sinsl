import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState, type FormEvent } from "react";
import { GROK_PROVIDERS, authEnabled, authClient, signIn } from "@/lib/auth/client";
import { loginFailed, loginGate, loginSucceeded } from "@/lib/sinal/fns";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const gate = await loginGate({ data: email });
      if (gate.locked) {
        setError(gate.message ?? "entrada travada");
        return;
      }
      const { error: err } = await authClient.signIn.email({ email, password });
      if (err) {
        await loginFailed({ data: email });
        setError("usuário ou senha inválidos");
        return;
      }
      await loginSucceeded({ data: email });
      await navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "falha no login");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="grid min-h-[70vh] place-items-center px-4 py-10">
      <div className="w-full max-w-sm rounded-lg border border-border bg-surface p-7">
        <h1 className="font-display text-xl font-semibold">Entrar no Sinal</h1>
        <p className="mt-1 mb-5 text-xs text-muted">Há trava contra tentativas em massa.</p>
        {authEnabled ? (
          <>
            <form className="flex flex-col gap-2.5" onSubmit={onSubmit}>
              <input
                type="email"
                required
                placeholder="e-mail"
                className="rounded-md border border-border bg-bg px-3 py-2.5 text-sm"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
              />
              <input
                type="password"
                required
                placeholder="senha"
                className="rounded-md border border-border bg-bg px-3 py-2.5 text-sm"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
              />
              {error ? <p className="text-xs text-danger">{error}</p> : <p className="min-h-4" />}
              <button
                type="submit"
                disabled={busy}
                className="rounded-md bg-signal py-2.5 text-sm font-medium text-bg disabled:opacity-60"
              >
                {busy ? "entrando…" : "Entrar"}
              </button>
            </form>
            <div className="my-4 h-px bg-border" />
            <div className="flex flex-col gap-2">
              {GROK_PROVIDERS.map((p) => (
                <button
                  key={p.providerId}
                  type="button"
                  onClick={() => signIn(p.providerId, { callbackURL: "/" })}
                  className="rounded-md border border-border px-3 py-2 text-sm text-fg hover:bg-surface-hover"
                >
                  Continuar com {p.label}
                </button>
              ))}
            </div>
          </>
        ) : (
          <p className="text-sm text-muted">Login desligado neste ambiente.</p>
        )}
        <p className="mt-4 text-sm text-muted">
          Sem conta?{" "}
          <Link to="/cadastro" className="text-signal underline">
            Cadastro
          </Link>
        </p>
      </div>
    </main>
  );
}
