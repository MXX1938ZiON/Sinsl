import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { CATEGORY_DEFS, COLLECTIONS, GENRES, type CatalogTitle } from "@/lib/sinal/catalog";
import { listCatalog } from "@/lib/sinal/fns";
import { padTo, PosterCard } from "@/components/sinal/poster-card";

type Search = { q?: string };

export const Route = createFileRoute("/")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    q: typeof s.q === "string" ? s.q : undefined,
  }),
  component: Home,
});

function Home() {
  const { q } = Route.useSearch();
  const [items, setItems] = useState<CatalogTitle[]>([]);

  useEffect(() => {
    void listCatalog().then(setItems);
  }, []);

  const filtered = useMemo(() => {
    const query = q?.toLowerCase().trim();
    if (!query) return items;
    return items.filter((it) => {
      if (it.title.toLowerCase().includes(query)) return true;
      if (it.synopsis?.toLowerCase().includes(query)) return true;
      if (it.category.toLowerCase().includes(query)) return true;
      const labels = it.genres.map((k) => GENRES.find((g) => g.key === k)?.label || k);
      return labels.some((l) => l.toLowerCase().includes(query));
    });
  }, [items, q]);

  const byViews = [...filtered].sort((a, b) => b.views - a.views);
  const byRecent = [...filtered].sort((a, b) => +new Date(b.addedAt) - +new Date(a.addedAt));
  const continuing = filtered.filter((i) => i.resumePct != null).slice(0, 10);
  const live = filtered.filter((i) => i.source === "iptv" || i.category === "ao-vivo");

  return (
    <div className="pb-16">
      <p className="max-w-3xl px-6 pt-5 text-sm leading-relaxed text-muted sm:px-10">
        Player P2P para um grupo pequeno. O servidor só semeia — quem toca é o navegador.
        Big Buck Bunny e Sintel (CC BY 3.0) via WebTorrent. Canais ao vivo em HLS. YouTube e
        Telegram pelo player oficial de cada um. Assistir exige assinatura ativa.
      </p>

      {continuing.length ? (
        <Row title="Continuar assistindo">
          {continuing.map((it) => (
            <PosterCard key={it.id} item={it} toPlayer />
          ))}
        </Row>
      ) : null}

      {live.length ? (
        <Row title="Ao vivo" note="IPTV · HLS">
          {live.map((it) => (
            <PosterCard key={it.id} item={it} />
          ))}
        </Row>
      ) : null}

      <Row title="Top 10 do Sinal">
        {padTo(byViews, 10).map((it, i) => (
          <PosterCard key={"id" in it ? it.id : `p-${i}`} item={it} rank={i + 1} />
        ))}
      </Row>

      <Row title="Adicionados recentemente">
        {byRecent.slice(0, 10).map((it) => (
          <PosterCard key={it.id} item={it} />
        ))}
      </Row>

      {CATEGORY_DEFS.filter((c) => c.key !== "ao-vivo").map((cat) => (
        <Row key={cat.key} title={`Top 10 — ${cat.label}`}>
          {padTo(
            byViews.filter((it) => it.category === cat.key),
            10,
          ).map((it, i) => (
            <PosterCard key={"id" in it ? it.id : `${cat.key}-${i}`} item={it} rank={i + 1} />
          ))}
        </Row>
      ))}

      <Row title="Coleções" note="cada card é um universo">
        {COLLECTIONS.map((c) => (
          <Link key={c.key} to="/colecao/$key" params={{ key: c.key }} className="w-[150px] shrink-0">
            <div className="flex aspect-2/3 items-end rounded-xs border border-border bg-linear-to-br from-surface to-cinema p-2.5 text-sm text-muted hover:border-accent">
              {c.title}
            </div>
            <p className="mt-2.5 text-sm">{c.title}</p>
          </Link>
        ))}
      </Row>
    </div>
  );
}

function Row({ title, note, children }: { title: string; note?: string; children: React.ReactNode }) {
  return (
    <section className="mt-8">
      <div className="mb-3.5 flex items-baseline gap-2.5 px-6 sm:px-10">
        <h2 className="font-display text-lg font-semibold">{title}</h2>
        {note ? <span className="text-xs text-muted">{note}</span> : null}
      </div>
      <div className="row-track">{children}</div>
    </section>
  );
}
