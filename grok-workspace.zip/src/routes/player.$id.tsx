import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { SinalPlayer } from "@/components/sinal/player";
import { getTitle } from "@/lib/sinal/fns";

export const Route = createFileRoute("/player/$id")({ component: PlayerPage });

function PlayerPage() {
  const { id } = Route.useParams();
  const [title, setTitle] = useState("Sinal");
  useEffect(() => {
    void getTitle({ data: id }).then((t) => {
      if (t) setTitle(t.title);
    });
  }, [id]);
  return <SinalPlayer id={id} title={title} />;
}
