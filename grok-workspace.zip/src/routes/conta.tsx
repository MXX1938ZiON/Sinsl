import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { RedirectToSignIn } from "@/lib/auth/gates";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { ensureMyProfile, subscribe, type SinalProfile } from "@/lib/sinal/fns";

export const Route = createFileRoute("/conta")({ component: Conta });

function Conta() {
  const { user, isPending } = useCurrentUserState();
  const [profile, setProfile] = useState<SinalProfile | null>(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    if (!user) return;
    void ensureMyProfile().then(setProfile);
  }, [user]);

  if (isPending) return <div className="h-40 animate-pulse bg-surface" />;
  if (!user) return <RedirectToSignIn />;

  const granted = Boolean(profile?.hasAccess);
  const status = !profile
    ? "carregando…"
    : granted
      ? profile.unlockedForever
        ? "liberado (indeterminado)"
        : profile.unlockedUntil
          ? `ativo até ${new Date(profile.unlockedUntil).toLocaleDateString("pt-BR")}`
          : "acesso de admin"
      : "sem assinatura ativa";

  async function pay() {
    setBusy(true);
    setError("");
    try {
      const next = await subscribe();
      setProfile(next);
    } catch (err) {
      setError(err instanceof Error ? err.message : "falha");
    } finally {
      setBusy(false);
    }
  }

  return (
    <main className="mx-auto flex max-w-md flex-col gap-4 px-5 py-8">
      <h1 className="font-display text-2xl font-semibold">Minha conta</h1>
      <div className="rounded-lg border border-border bg-surface p-6">
        <Row label="usuário" value={profile?.username ?? user.displayName ?? "—"} />
        <Row label="e-mail" value={user.primaryEmail ?? "—"} />
        <Row label="assinatura" value={status} />
        {!granted ? (
          <>
            <button
              type="button"
              disabled={busy}
              onClick={() => void pay()}
              className="mt-4 w-full rounded-md bg-signal py-2.5 text-sm font-medium text-bg"
            >
              {busy ? "ativando…" : "Assinar 30 dias"}
            </button>
            <p className="mt-2 text-xs leading-normal text-muted">
              Pagamento ainda é simulado nesta versão. Ao ativar, o Sinal envia o e-mail de
              parabéns e o comprovante (e avisa no Telegram, se o admin ligou o bot).
            </p>
          </>
        ) : (
          <p className="mt-3 text-xs text-muted">
            Comprovante e mensagem de boas-vindas foram para o seu e-mail (ou para a fila, se o
            envio real ainda não está configurado).
          </p>
        )}
        {error ? <p className="mt-2 text-xs text-danger">{error}</p> : null}
      </div>
    </main>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <p className="mb-2.5 flex justify-between gap-4 text-sm">
      <span className="text-muted">{label}</span>
      <span>{value}</span>
    </p>
  );
}
