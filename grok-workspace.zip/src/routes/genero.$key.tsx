import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { GENRES, type CatalogTitle } from "@/lib/sinal/catalog";
import { listCatalog } from "@/lib/sinal/fns";
import { PosterCard } from "@/components/sinal/poster-card";

export const Route = createFileRoute("/genero/$key")({ component: GenrePage });

function GenrePage() {
  const { key } = Route.useParams();
  const genre = GENRES.find((g) => g.key === key);
  const [items, setItems] = useState<CatalogTitle[]>([]);
  useEffect(() => {
    void listCatalog().then((all) => setItems(all.filter((i) => i.genres.includes(key))));
  }, [key]);

  return (
    <main className="pb-16">
      <div className="flex items-center gap-4 px-6 pt-7 sm:px-10">
        <Link to="/" className="text-sm text-muted hover:text-fg">
          ← início
        </Link>
        <h1 className="font-display text-2xl font-semibold">{genre?.label ?? key}</h1>
      </div>
      <p className="mt-1 max-w-xl px-6 text-sm text-muted sm:px-10">
        {items.length ? "Conteúdo neste gênero." : "Ainda sem título neste gênero — a página já existe."}
      </p>
      <div className="grid grid-cols-[repeat(auto-fill,minmax(150px,1fr))] gap-4 px-6 py-6 sm:px-10">
        {items.map((it) => (
          <PosterCard key={it.id} item={it} />
        ))}
      </div>
    </main>
  );
}
