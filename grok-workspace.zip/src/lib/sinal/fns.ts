import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import { optionalAuthMiddleware } from "./optional-auth";
import {
  filterByRestrictions,
  getProfile,
  loadSettings,
  mapTitle,
  uniqueUsername,
  usernameTaken,
  type TitleRow,
} from "./db.server";
import type { CatalogTitle, SinalProfile } from "./catalog";
import {
  checkLoginLock,
  clearLoginFails,
  consumeSignupTicket,
  countSince,
  guardNewProfile,
  guardRequest,
  guardSignup,
  issueChallenge,
  recordLoginFail,
} from "./spam.server";
import { clientIp } from "./ip.server";
import { enqueueEmail, notifyTelegram, userMail } from "./emails.server";
import { telegramEmbedUrl } from "./media";

async function hydrateCatalog(userId: string | null): Promise<CatalogTitle[]> {
  const sql = await getSql();
  const titles = await sql<TitleRow>`select * from sinal_titles order by added_at desc`;
  const profile = userId ? await getProfile(userId) : null;
  const granted = Boolean(profile?.hasAccess);
  const filtered = filterByRestrictions(titles, profile);

  const ratingRows = await sql<{ title_id: string; avg: number; n: number }>`
    select title_id, avg(stars)::float as avg, count(*)::int as n from sinal_ratings group by title_id`;
  const ratingMap = Object.fromEntries(ratingRows.map((r) => [r.title_id, r]));

  let myRatings: Record<string, number> = {};
  let progress: Record<string, { seconds: number; duration: number }> = {};
  if (userId) {
    const mine = await sql<{ title_id: string; stars: number }>`
      select title_id, stars from sinal_ratings where user_id = ${userId}`;
    myRatings = Object.fromEntries(mine.map((r) => [r.title_id, r.stars]));
    const prog = await sql<{ title_id: string; seconds: number; duration: number }>`
      select title_id, seconds, duration from sinal_progress where user_id = ${userId}`;
    progress = Object.fromEntries(prog.map((p) => [p.title_id, p]));
  }

  return filtered.map((row) => {
    const p = progress[row.id];
    const resumePct =
      p && p.duration > 0 && p.seconds > 5 && p.seconds / p.duration < 0.95
        ? Math.round((p.seconds / p.duration) * 100)
        : null;
    const r = ratingMap[row.id];
    return mapTitle(row, {
      granted,
      avgRating: r ? Number(r.avg) : null,
      ratingCount: r?.n ?? 0,
      myRating: myRatings[row.id] ?? null,
      resumePct,
    });
  });
}

export const getPublicConfig = createServerFn({ method: "GET" }).handler(async () => {
  const settings = await loadSettings();
  const sql = await getSql();
  const maint = await sql<{ mode: string; message: string }>`
    select mode, message from sinal_maintenance where id = 1`;
  return {
    signupMode: settings.signupMode,
    maintenance: maint[0] ?? { mode: "none", message: "" },
  };
});

export const listCatalog = createServerFn({ method: "GET" })
  .middleware([optionalAuthMiddleware])
  .handler(async ({ context }) => hydrateCatalog(context.userId));

export const getTitle = createServerFn({ method: "GET" })
  .middleware([optionalAuthMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }) => {
    const items = await hydrateCatalog(context.userId);
    return items.find((t) => t.id === id) ?? null;
  });

export const ensureMyProfile = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const existing = await getProfile(context.userId);
    if (existing) return existing;
    await guardNewProfile();
    const sql = await getSql();
    const count = await sql<{ n: number }>`select count(*)::int as n from sinal_profiles`;
    const mail = await userMail(context.userId);
    const base = (mail?.name || mail?.email?.split("@")[0] || "sinal").slice(0, 18);
    let username = base.replace(/[^a-zA-Z0-9._-]/g, "") || "sinal";
    if (await usernameTaken(username)) username = uniqueUsername(username);
    const role = (count[0]?.n ?? 0) === 0 ? "admin" : "user";
    await sql`insert into sinal_profiles (user_id, username, role, status)
      values (${context.userId}, ${username}, ${role}, 'active')
      on conflict (user_id) do nothing`;
    if (mail?.email) {
      await enqueueEmail({
        userId: context.userId,
        toEmail: mail.email,
        template: "welcome",
        ctx: { name: username },
      });
    }
    const created = await getProfile(context.userId);
    if (!created) throw new Error("não foi possível criar o perfil");
    return created;
  });

export const getMyProfile = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => getProfile(context.userId));

export const claimSignupTicket = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { ticket: string; username: string }) => input)
  .handler(async ({ context, data }) => {
    const username = data.username.trim().slice(0, 24);
    if (username.length < 3) throw new Error("usuário precisa ter pelo menos 3 caracteres");
    if (await usernameTaken(username)) throw new Error("nome de usuário já existe");
    const { inviteCode } = await consumeSignupTicket(data.ticket);
    const sql = await getSql();
    const count = await sql<{ n: number }>`select count(*)::int as n from sinal_profiles`;
    const role = (count[0]?.n ?? 0) === 0 ? "admin" : "user";
    let unlockedForever = false;
    let unlockedUntil: string | null = null;
    if (inviteCode) {
      const inv = await sql<{ mode: string; days: number | null; used_by: string | null }>`
        select mode, days, used_by from sinal_invites where code = ${inviteCode} limit 1`;
      const invite = inv[0];
      if (invite && !invite.used_by) {
        if (invite.mode === "temporary" && invite.days) {
          unlockedUntil = new Date(Date.now() + invite.days * 86400000).toISOString();
        } else {
          unlockedForever = true;
        }
        await sql`update sinal_invites set used_by = ${username}, used_at = now() where code = ${inviteCode}`;
      }
    }
    await sql`insert into sinal_profiles (user_id, username, role, status, unlocked_until, unlocked_forever)
      values (${context.userId}, ${username}, ${role}, 'active', ${unlockedUntil}, ${unlockedForever})
      on conflict (user_id) do update set username = ${username}`;
    const mail = await userMail(context.userId);
    if (mail?.email) {
      await enqueueEmail({
        userId: context.userId,
        toEmail: mail.email,
        template: "welcome",
        ctx: { name: username },
      });
    }
    return getProfile(context.userId);
  });

export const prepareSignup = createServerFn({ method: "POST" })
  .validator(
    (input: {
      honeypot: string;
      startedAt: number;
      challengeId: string;
      taps: number[];
      inviteCode: string;
    }) => input,
  )
  .handler(async ({ data }) => {
    const ticket = await guardSignup(data);
    return { ticket };
  });

export const fetchChallenge = createServerFn({ method: "POST" }).handler(async () => issueChallenge());

export const loginGate = createServerFn({ method: "POST" })
  .validator((email: string) => email)
  .handler(async ({ data: email }) => checkLoginLock(email));

export const loginFailed = createServerFn({ method: "POST" })
  .validator((email: string) => email)
  .handler(async ({ data: email }) => {
    await recordLoginFail(email);
    return { ok: true };
  });

export const loginSucceeded = createServerFn({ method: "POST" })
  .validator((email: string) => email)
  .handler(async ({ data: email }) => {
    await clearLoginFails(email);
    return { ok: true };
  });

export const subscribe = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const profile = await getProfile(context.userId);
    if (!profile) throw new Error("crie o perfil antes de assinar");
    if (profile.status !== "active") throw new Error("conta desativada");
    const until = new Date(Date.now() + 30 * 86400000);
    const sql = await getSql();
    await sql`update sinal_profiles set unlocked_until = ${until.toISOString()}, unlocked_forever = false
      where user_id = ${context.userId}`;
    const mail = await userMail(context.userId);
    const untilLabel = until.toLocaleDateString("pt-BR");
    if (mail?.email) {
      await enqueueEmail({
        userId: context.userId,
        toEmail: mail.email,
        template: "subscribed",
        ctx: { name: profile.username, until: untilLabel },
      });
      await enqueueEmail({
        userId: context.userId,
        toEmail: mail.email,
        template: "receipt",
        ctx: { name: profile.username, until: untilLabel, amount: "R$ 0,00 (simulado)" },
      });
    }
    await notifyTelegram(`<b>${profile.username}</b> assinou o Sinal até ${untilLabel}.`);
    return getProfile(context.userId);
  });

export type Playback =
  | { kind: "magnet"; magnet: string; dubbed: boolean }
  | { kind: "youtube"; youtubeId: string }
  | { kind: "hls"; hlsUrl: string }
  | { kind: "telegram"; telegramUrl: string; embedUrl: string };

export const getPlayback = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((titleId: string) => titleId)
  .handler(async ({ context, data: titleId }): Promise<Playback> => {
    const profile = await getProfile(context.userId);
    if (!profile?.hasAccess) throw new Error("assinatura necessária");
    const sql = await getSql();
    const rows = await sql<TitleRow>`select * from sinal_titles where id = ${titleId} limit 1`;
    const row = rows[0];
    if (!row) throw new Error("título não encontrado");
    await sql`update sinal_titles set views = views + 1 where id = ${titleId}`;
    if (row.source === "youtube" && row.youtube_id) return { kind: "youtube", youtubeId: row.youtube_id };
    if (row.source === "iptv" && row.hls_url) return { kind: "hls", hlsUrl: row.hls_url };
    if (row.source === "telegram" && row.telegram_url) {
      const embed = telegramEmbedUrl(row.telegram_url);
      if (!embed) throw new Error("link do Telegram inválido");
      return { kind: "telegram", telegramUrl: row.telegram_url, embedUrl: embed };
    }
    if (row.magnet) return { kind: "magnet", magnet: row.magnet, dubbed: Boolean(row.dubbed) };
    if (row.hls_url) return { kind: "hls", hlsUrl: row.hls_url };
    throw new Error("sem arquivo neste título");
  });

export const saveProgress = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { titleId: string; seconds: number; duration: number }) => input)
  .handler(async ({ context, data }) => {
    if (!data.duration || data.seconds < 0) return { ok: true };
    const sql = await getSql();
    await sql`insert into sinal_progress (user_id, title_id, seconds, duration, updated_at)
      values (${context.userId}, ${data.titleId}, ${data.seconds}, ${data.duration}, now())
      on conflict (user_id, title_id) do update set
        seconds = ${data.seconds}, duration = ${data.duration}, updated_at = now()`;
    return { ok: true };
  });

export const getProgress = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((titleId: string) => titleId)
  .handler(async ({ context, data: titleId }) => {
    const sql = await getSql();
    const rows = await sql<{ seconds: number; duration: number }>`
      select seconds, duration from sinal_progress
      where user_id = ${context.userId} and title_id = ${titleId} limit 1`;
    return rows[0] ?? null;
  });

export const rateTitle = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { titleId: string; stars: number }) => input)
  .handler(async ({ context, data }) => {
    const stars = Math.min(5, Math.max(1, Math.round(data.stars)));
    const sql = await getSql();
    await sql`insert into sinal_ratings (user_id, title_id, stars)
      values (${context.userId}, ${data.titleId}, ${stars})
      on conflict (user_id, title_id) do update set stars = ${stars}`;
    return { ok: true };
  });

export const sendRequest = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((body: string) => body)
  .handler(async ({ context, data: body }) => {
    const text = body.trim().slice(0, 280);
    if (text.length < 3) throw new Error("escreva o que você procura");
    await guardRequest();
    const sql = await getSql();
    await sql`insert into sinal_requests (user_id, body) values (${context.userId}, ${text})`;
    return { ok: true };
  });

export const askAssistant = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { mode: "suporte" | "vendas" | "tecnico"; message: string }) => input)
  .handler(async ({ context, data }) => {
    const message = data.message.trim().slice(0, 800);
    if (message.length < 2) throw new Error("escreva sua pergunta");
    const ip = clientIp();
    const recent = await countSince("signup", ip, 1);
    void recent;
    const sql = await getSql();
    const hour = await sql<{ n: number }>`
      select count(*)::int as n from sinal_assistant_messages
      where user_id = ${context.userId} and role = 'user'
        and created_at > now() - interval '1 hour'`;
    if ((hour[0]?.n ?? 0) >= 20) throw new Error("muitas perguntas nesta hora — volte em instantes");

    const profile = await getProfile(context.userId);
    await sql`insert into sinal_assistant_messages (user_id, mode, role, content)
      values (${context.userId}, ${data.mode}, 'user', ${message})`;

    const history = await sql<{ role: string; content: string }>`
      select role, content from sinal_assistant_messages
      where user_id = ${context.userId} and mode = ${data.mode}
      order by created_at desc limit 8`;

    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      const fallback =
        "O assistente IA não está disponível neste ambiente. Para suporte: cadastro livre, assistir exige assinatura de 30 dias, P2P no navegador, IPTV via HLS e Telegram pelo player embutido.";
      await sql`insert into sinal_assistant_messages (user_id, mode, role, content)
        values (${context.userId}, ${data.mode}, 'assistant', ${fallback})`;
      return { text: fallback };
    }

    const modeHint =
      data.mode === "vendas"
        ? "Você é consultor de vendas do Sinal. Explique o plano de 30 dias, convites e o que o admin libera. Não invente preço além de assinatura simulada nesta versão."
        : data.mode === "tecnico"
          ? "Você é suporte técnico do Sinal. Ajude com player P2P (WebTorrent), IPTV HLS, embed do YouTube/Telegram, buffer, legendas e login. Nunca peça magnet pra quem não tem assinatura."
          : "Você é suporte do Sinal. Ajude com conta, cadastro, prova de sinal anti-spam, restrições e navegação do catálogo.";

    const system = `Você é o assistente do Sinal, player P2P estilo Plex para um grupo pequeno.
${modeHint}
Regras: responda em português, curto e direto. Não invente títulos que não existem. Não entregue magnet links. Usuário atual: ${profile?.username ?? "visitante"}, acesso: ${profile?.hasAccess ? "ativo" : "sem assinatura"}, papel: ${profile?.role ?? "user"}.`;

    const messages = [
      { role: "system" as const, content: system },
      ...history.reverse().map((m) => ({
        role: (m.role === "assistant" ? "assistant" : "user") as "assistant" | "user",
        content: m.content,
      })),
    ];

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({ model: "grok-4.5", messages, max_tokens: 500 }),
    });
    if (!res.ok) throw new Error("o assistente falhou agora — tente de novo");
    const body = (await res.json()) as { choices?: { message?: { content?: string } }[] };
    const text = body.choices?.[0]?.message?.content?.trim() || "Não consegui responder agora.";
    await sql`insert into sinal_assistant_messages (user_id, mode, role, content)
      values (${context.userId}, ${data.mode}, 'assistant', ${text})`;
    return { text };
  });

export const listAssistantHistory = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((mode: "suporte" | "vendas" | "tecnico") => mode)
  .handler(async ({ context, data: mode }) => {
    const sql = await getSql();
    const rows = await sql<{ role: string; content: string; created_at: string }>`
      select role, content, created_at from sinal_assistant_messages
      where user_id = ${context.userId} and mode = ${mode}
      order by created_at desc limit 16`;
    return rows.reverse();
  });

export type { CatalogTitle, SinalProfile };
