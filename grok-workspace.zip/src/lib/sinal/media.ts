export function extractYouTubeId(url: string): string | null {
  try {
    const u = new URL(url);
    if (u.hostname === "youtu.be") return u.pathname.slice(1).split("/")[0] || null;
    if (u.hostname.includes("youtube.com")) {
      if (u.pathname === "/watch") return u.searchParams.get("v");
      if (u.pathname.startsWith("/embed/")) return u.pathname.split("/embed/")[1]?.split("/")[0] ?? null;
      if (u.pathname.startsWith("/shorts/")) return u.pathname.split("/shorts/")[1]?.split("/")[0] ?? null;
    }
  } catch {
    return null;
  }
  return null;
}

export function telegramEmbedUrl(url: string): string | null {
  try {
    const u = new URL(url);
    if (!u.hostname.endsWith("t.me") && !u.hostname.endsWith("telegram.me")) return null;
    const parts = u.pathname.split("/").filter(Boolean);
    if (parts.length < 2) return null;
    return `https://t.me/${parts[0]}/${parts[1]}?embed=1`;
  } catch {
    return null;
  }
}

export function parseM3u(text: string): { title: string; url: string }[] {
  const lines = text.split(/\r?\n/);
  const out: { title: string; url: string }[] = [];
  let pending = "Canal";
  for (const raw of lines) {
    const line = raw.trim();
    if (!line || line.startsWith("#EXTM3U")) continue;
    if (line.startsWith("#EXTINF")) {
      const comma = line.indexOf(",");
      pending = comma >= 0 ? line.slice(comma + 1).trim() || "Canal" : "Canal";
      continue;
    }
    if (line.startsWith("#")) continue;
    if (/^https?:\/\//i.test(line)) {
      out.push({ title: pending.slice(0, 80), url: line });
      pending = "Canal";
    }
  }
  return out.slice(0, 80);
}
