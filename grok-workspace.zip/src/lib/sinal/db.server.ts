import { randomBytes } from "node:crypto";
import { getSql } from "@/lib/db";
import { RATING_RANK, type CatalogTitle, type SinalProfile } from "./catalog";

export type Settings = {
  signupMode: "challenge" | "invite_only" | "closed";
  signupPerIpHour: number;
  loginMaxFails: number;
  loginLockoutMinutes: number;
  requestsPerHour: number;
  minFormSeconds: number;
};

const DEFAULTS: Settings = {
  signupMode: "challenge",
  signupPerIpHour: 3,
  loginMaxFails: 5,
  loginLockoutMinutes: 15,
  requestsPerHour: 3,
  minFormSeconds: 3,
};

function parseJsonArray(raw: string | null | undefined): string[] {
  if (!raw) return [];
  try {
    const v = JSON.parse(raw) as unknown;
    return Array.isArray(v) ? v.filter((x): x is string => typeof x === "string") : [];
  } catch {
    return [];
  }
}

export async function loadSettings(): Promise<Settings> {
  const sql = await getSql();
  const rows = await sql<{ key: string; value: string }>`select key, value from sinal_settings`;
  const map = Object.fromEntries(rows.map((r) => [r.key, r.value]));
  const mode = map.signup_mode;
  return {
    signupMode:
      mode === "invite_only" || mode === "closed" || mode === "challenge"
        ? mode
        : DEFAULTS.signupMode,
    signupPerIpHour: Number(map.signup_per_ip_hour) || DEFAULTS.signupPerIpHour,
    loginMaxFails: Number(map.login_max_fails) || DEFAULTS.loginMaxFails,
    loginLockoutMinutes: Number(map.login_lockout_minutes) || DEFAULTS.loginLockoutMinutes,
    requestsPerHour: Number(map.requests_per_hour) || DEFAULTS.requestsPerHour,
    minFormSeconds: Number(map.min_form_seconds) || DEFAULTS.minFormSeconds,
  };
}

export async function saveSettings(patch: Partial<Settings>): Promise<Settings> {
  const current = await loadSettings();
  const next: Settings = { ...current, ...patch };
  const sql = await getSql();
  const entries: [string, string][] = [
    ["signup_mode", next.signupMode],
    ["signup_per_ip_hour", String(next.signupPerIpHour)],
    ["login_max_fails", String(next.loginMaxFails)],
    ["login_lockout_minutes", String(next.loginLockoutMinutes)],
    ["requests_per_hour", String(next.requestsPerHour)],
    ["min_form_seconds", String(next.minFormSeconds)],
  ];
  for (const [key, value] of entries) {
    await sql`insert into sinal_settings (key, value) values (${key}, ${value})
      on conflict (key) do update set value = ${value}`;
  }
  return next;
}

export function profileHasAccess(p: {
  role: string;
  unlockedForever: boolean;
  unlockedUntil: string | null;
  status: string;
}): boolean {
  if (p.status !== "active") return false;
  if (p.role === "admin") return true;
  if (p.unlockedForever) return true;
  if (!p.unlockedUntil) return false;
  return new Date(p.unlockedUntil) > new Date();
}

type ProfileRow = {
  user_id: string;
  username: string;
  role: string;
  status: string;
  unlocked_until: string | null;
  unlocked_forever: boolean;
  restrictions_categories: string;
  restrictions_genres: string;
  max_age_rating: string | null;
  created_at: string;
};

export function mapProfile(row: ProfileRow): SinalProfile {
  const unlockedForever = Boolean(row.unlocked_forever);
  const base = {
    userId: row.user_id,
    username: row.username,
    role: (row.role === "admin" || row.role === "trial" ? row.role : "user") as SinalProfile["role"],
    status: (row.status === "disabled" ? "disabled" : "active") as SinalProfile["status"],
    unlockedUntil: row.unlocked_until,
    unlockedForever,
    restrictionsCategories: parseJsonArray(row.restrictions_categories),
    restrictionsGenres: parseJsonArray(row.restrictions_genres),
    maxAgeRating: row.max_age_rating,
    createdAt: row.created_at,
  };
  return { ...base, hasAccess: profileHasAccess(base) };
}

export async function getProfile(userId: string): Promise<SinalProfile | null> {
  const sql = await getSql();
  const rows = await sql<ProfileRow>`select * from sinal_profiles where user_id = ${userId} limit 1`;
  return rows[0] ? mapProfile(rows[0]) : null;
}

export async function listProfiles(): Promise<SinalProfile[]> {
  const sql = await getSql();
  const rows = await sql<ProfileRow>`select * from sinal_profiles order by created_at desc`;
  return rows.map(mapProfile);
}

export async function countProfiles(): Promise<number> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`select count(*)::int as n from sinal_profiles`;
  return rows[0]?.n ?? 0;
}

export async function usernameTaken(username: string): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from sinal_profiles where lower(username) = ${username.toLowerCase()}`;
  return (rows[0]?.n ?? 0) > 0;
}

export function uniqueUsername(base: string): string {
  const cleaned = base.replace(/[^a-zA-Z0-9._-]/g, "").slice(0, 18) || "sinal";
  return `${cleaned}-${randomBytes(2).toString("hex")}`;
}

type TitleRow = {
  id: string;
  title: string;
  category: string;
  genres: string;
  age_rating: string | null;
  dubbed: boolean;
  synopsis: string | null;
  poster: string | null;
  poster_credit: string | null;
  views: number;
  added_at: string;
  magnet: string | null;
  youtube_id: string | null;
  hls_url: string | null;
  telegram_url: string | null;
  source: string;
};

export type { TitleRow };

export function mapTitle(
  row: TitleRow,
  opts: {
    granted: boolean;
    avgRating: number | null;
    ratingCount: number;
    myRating: number | null;
    resumePct: number | null;
  },
): CatalogTitle {
  const hasStream = Boolean(row.magnet || row.youtube_id || row.hls_url || row.telegram_url);
  return {
    id: row.id,
    title: row.title,
    category: row.category,
    genres: parseJsonArray(row.genres),
    ageRating: row.age_rating,
    dubbed: Boolean(row.dubbed),
    synopsis: row.synopsis,
    poster: row.poster,
    posterCredit: row.poster_credit,
    views: Number(row.views) || 0,
    addedAt: row.added_at,
    source: row.source,
    youtubeId: opts.granted ? row.youtube_id : null,
    hlsUrl: opts.granted ? row.hls_url : null,
    telegramUrl: opts.granted ? row.telegram_url : null,
    hasStream,
    locked: hasStream && !opts.granted,
    avgRating: opts.avgRating,
    ratingCount: opts.ratingCount,
    myRating: opts.myRating,
    resumePct: opts.resumePct,
  };
}

export function filterByRestrictions(rows: TitleRow[], profile: SinalProfile | null): TitleRow[] {
  if (!profile) return rows;
  let items = rows;
  if (profile.restrictionsCategories.length) {
    items = items.filter((i) => profile.restrictionsCategories.includes(i.category));
  }
  if (profile.restrictionsGenres.length) {
    items = items.filter((i) =>
      parseJsonArray(i.genres).some((g) => profile.restrictionsGenres.includes(g)),
    );
  }
  if (profile.maxAgeRating) {
    const max = RATING_RANK[profile.maxAgeRating] ?? 99;
    items = items.filter((i) => !i.age_rating || (RATING_RANK[i.age_rating] ?? 99) <= max);
  }
  return items;
}

export { parseJsonArray };
