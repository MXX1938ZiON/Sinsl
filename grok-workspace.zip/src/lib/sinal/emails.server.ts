import { getSql } from "@/lib/db";

export type EmailTemplate =
  | "welcome"
  | "subscribed"
  | "receipt"
  | "billing"
  | "invite";

type UserMail = { email: string; name: string };

export async function userMail(userId: string): Promise<UserMail | null> {
  const sql = await getSql();
  const rows = await sql<UserMail>`
    select "email" as email, "name" as name from "user" where "id" = ${userId} limit 1`;
  return rows[0] ?? null;
}

function wrapHtml(title: string, inner: string): string {
  return `<!doctype html>
<html><body style="margin:0;background:#14120f;color:#f2e9dd;font-family:Georgia,serif;">
  <div style="max-width:520px;margin:32px auto;padding:28px;background:#1e1b17;border:1px solid #332e27;border-radius:10px;">
    <p style="font-size:22px;margin:0 0 8px;"><span style="color:#f2e9dd">Si</span><span style="color:#e8c547">nal</span></p>
    <h1 style="font-size:20px;margin:0 0 16px;">${title}</h1>
    <div style="font-family:Arial,sans-serif;font-size:14px;line-height:1.6;color:#f2e9dd">${inner}</div>
    <p style="font-size:11px;color:#9a8f80;margin-top:24px;">Grupo pequeno, player leve. Se não foi você, ignore este e-mail.</p>
  </div>
</body></html>`;
}

export function buildEmail(
  template: EmailTemplate,
  ctx: { name: string; until?: string; amount?: string; invite?: string },
): { subject: string; body: string } {
  const name = ctx.name || "assinante";
  switch (template) {
    case "welcome":
      return {
        subject: "Bem-vindo ao Sinal",
        body: wrapHtml(
          "Sua conta está pronta",
          `<p>Olá, ${name}.</p><p>O catálogo já pode ser navegado. Para assistir de verdade — P2P, IPTV, YouTube ou Telegram — ative a assinatura de 30 dias em Minha conta.</p>`,
        ),
      };
    case "subscribed":
      return {
        subject: "Parabéns — sua assinatura Sinal está ativa",
        body: wrapHtml(
          "Parabéns por ter assinado",
          `<p>Olá, ${name}.</p><p>Sua assinatura está ativa${ctx.until ? ` até <strong>${ctx.until}</strong>` : ""}.</p><p>Pode assistir em qualquer aparelho com a mesma conta. Bom filme.</p>`,
        ),
      };
    case "receipt":
      return {
        subject: "Comprovante de assinatura — Sinal",
        body: wrapHtml(
          "Comprovante",
          `<p>Recebemos sua assinatura Sinal (30 dias).</p>
           <p>Valor: <strong>${ctx.amount ?? "R$ 0,00 (simulado)"}</strong></p>
           <p>Vigência: ${ctx.until ?? "30 dias"}</p>
           <p>Este comprovante não substitui nota fiscal. Pagamento real ainda não está ligado.</p>`,
        ),
      };
    case "billing":
      return {
        subject: "Lembrete de cobrança — Sinal",
        body: wrapHtml(
          "Sua assinatura está perto do fim",
          `<p>Olá, ${name}.</p><p>Acesso ativo até ${ctx.until ?? "em breve"}. Renove em Minha conta para não perder o swarm.</p>`,
        ),
      };
    case "invite":
      return {
        subject: "Seu convite Sinal",
        body: wrapHtml(
          "Você foi convidado",
          `<p>Use o código <strong>${ctx.invite ?? ""}</strong> no cadastro para liberar o acesso.</p>`,
        ),
      };
  }
}

async function deliver(to: string, subject: string, body: string): Promise<{ status: string; error: string | null }> {
  const sql = await getSql();
  const keyRows = await sql<{ value: string }>`select value from sinal_settings where key = 'resend_api_key' limit 1`;
  const apiKey = keyRows[0]?.value?.trim();
  if (!apiKey) return { status: "queued", error: null };

  try {
    const res = await fetch("https://api.resend.com/emails", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${apiKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        from: "Sinal <sinal@example.com>",
        to: [to],
        subject,
        html: body,
      }),
    });
    if (!res.ok) {
      const text = await res.text();
      return { status: "failed", error: text.slice(0, 280) };
    }
    return { status: "sent", error: null };
  } catch (err) {
    return { status: "failed", error: err instanceof Error ? err.message : "falha no envio" };
  }
}

export async function enqueueEmail(opts: {
  userId: string | null;
  toEmail: string;
  template: EmailTemplate;
  ctx: { name: string; until?: string; amount?: string; invite?: string };
}): Promise<void> {
  const built = buildEmail(opts.template, opts.ctx);
  const result = await deliver(opts.toEmail, built.subject, built.body);
  const sql = await getSql();
  await sql`insert into sinal_emails (user_id, to_email, template, subject, body, status, error)
    values (${opts.userId}, ${opts.toEmail}, ${opts.template}, ${built.subject}, ${built.body}, ${result.status}, ${result.error})`;
}

export async function notifyTelegram(text: string): Promise<void> {
  const sql = await getSql();
  const tokenRows = await sql<{ value: string }>`select value from sinal_settings where key = 'telegram_bot_token' limit 1`;
  const chatRows = await sql<{ value: string }>`select value from sinal_settings where key = 'telegram_chat_id' limit 1`;
  const token = tokenRows[0]?.value?.trim();
  const chat = chatRows[0]?.value?.trim();
  if (!token || !chat) return;
  try {
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chat, text, parse_mode: "HTML" }),
    });
  } catch {
    /* bot ausente ou rede bloqueada — o e-mail/outbox já registrou o evento */
  }
}
