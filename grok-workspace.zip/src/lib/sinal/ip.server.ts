import { getRequest } from "@tanstack/react-start/server";

export function clientIp(): string {
  try {
    const req = getRequest();
    if (!req) return "preview";
    const xff = req.headers.get("x-forwarded-for");
    if (xff) {
      const first = xff.split(",")[0]?.trim();
      if (first) return first.slice(0, 64);
    }
    const real = req.headers.get("x-real-ip")?.trim();
    if (real) return real.slice(0, 64);
    return "preview";
  } catch {
    return "preview";
  }
}
