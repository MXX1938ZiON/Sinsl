import { randomBytes, timingSafeEqual } from "node:crypto";
import { getSql } from "@/lib/db";
import { clientIp } from "./ip.server";
import { loadSettings } from "./db.server";

export type SpamKind = "signup" | "login" | "request" | "challenge" | "profile";

async function logEvent(
  kind: SpamKind,
  outcome: "allowed" | "blocked",
  reason: string | null,
  detail?: string,
) {
  const sql = await getSql();
  const ip = clientIp();
  await sql`insert into sinal_spam_events (kind, ip, outcome, reason, detail)
    values (${kind}, ${ip}, ${outcome}, ${reason}, ${detail ?? null})`;
}

export async function isIpBlocked(ip = clientIp()): Promise<boolean> {
  const sql = await getSql();
  const rows = await sql<{ ip: string }>`select ip from sinal_ip_blocks where ip = ${ip} limit 1`;
  return Boolean(rows[0]);
}

export async function countSince(kind: SpamKind, ip: string, hours: number): Promise<number> {
  const sql = await getSql();
  const rows = await sql<{ n: number }>`
    select count(*)::int as n from sinal_spam_events
    where kind = ${kind} and ip = ${ip} and outcome = 'allowed'
      and created_at > now() - (${hours} || ' hours')::interval`;
  return rows[0]?.n ?? 0;
}

export async function assertNotBlocked(): Promise<void> {
  if (await isIpBlocked()) {
    await logEvent("signup", "blocked", "ip_blocklisted");
    throw new Error("este endereço está bloqueado");
  }
}

export async function issueChallenge(): Promise<{ id: string; pattern: number[] }> {
  await assertNotBlocked();
  const ip = clientIp();
  const issued = await countSince("challenge", ip, 1);
  if (issued >= 30) {
    await logEvent("challenge", "blocked", "rate_challenge");
    throw new Error("muitas tentativas — espere um pouco");
  }
  const sql = await getSql();
  await sql`delete from sinal_challenges where expires_at < now()`;
  const id = randomBytes(16).toString("hex");
  const pattern = Array.from({ length: 4 }, () => Math.floor(Math.random() * 5));
  await sql`insert into sinal_challenges (id, pattern, expires_at)
    values (${id}, ${JSON.stringify(pattern)}, now() + interval '5 minutes')`;
  await logEvent("challenge", "allowed", null);
  return { id, pattern };
}

function samePattern(a: number[], b: number[]): boolean {
  if (a.length !== b.length) return false;
  const left = Buffer.from(JSON.stringify(a));
  const right = Buffer.from(JSON.stringify(b));
  if (left.length !== right.length) return false;
  return timingSafeEqual(left, right);
}

export async function consumeChallenge(id: string, taps: number[]): Promise<void> {
  const sql = await getSql();
  const rows = await sql<{ pattern: string; used: boolean; expires_at: string }>`
    select pattern, used, expires_at from sinal_challenges where id = ${id} limit 1`;
  const row = rows[0];
  if (!row) {
    await logEvent("signup", "blocked", "challenge_missing");
    throw new Error("prova de sinal expirada — tente de novo");
  }
  if (row.used) {
    await logEvent("signup", "blocked", "challenge_reused");
    throw new Error("prova de sinal já usada — sintonize de novo");
  }
  if (new Date(row.expires_at) < new Date()) {
    await logEvent("signup", "blocked", "challenge_expired");
    throw new Error("prova de sinal expirada — tente de novo");
  }
  let expected: number[] = [];
  try {
    expected = JSON.parse(row.pattern) as number[];
  } catch {
    expected = [];
  }
  if (!samePattern(expected, taps)) {
    await logEvent("signup", "blocked", "challenge_wrong");
    throw new Error("o sinal não bateu — observe as barras e repita");
  }
  await sql`update sinal_challenges set used = true where id = ${id}`;
}

export async function mintSignupTicket(inviteCode: string | null): Promise<string> {
  const sql = await getSql();
  const ticket = randomBytes(24).toString("hex");
  await sql`insert into sinal_signup_tickets (ticket, expires_at, invite_code)
    values (${ticket}, now() + interval '10 minutes', ${inviteCode})`;
  return ticket;
}

export async function consumeSignupTicket(ticket: string): Promise<{ inviteCode: string | null }> {
  const sql = await getSql();
  const rows = await sql<{ used: boolean; expires_at: string; invite_code: string | null }>`
    select used, expires_at, invite_code from sinal_signup_tickets where ticket = ${ticket} limit 1`;
  const row = rows[0];
  if (!row) throw new Error("cadastro sem autorização da trava — refaça a prova de sinal");
  if (row.used) throw new Error("este cadastro já foi usado");
  if (new Date(row.expires_at) < new Date()) throw new Error("a autorização expirou — refaça o cadastro");
  await sql`update sinal_signup_tickets set used = true where ticket = ${ticket}`;
  return { inviteCode: row.invite_code };
}

export async function guardSignup(input: {
  honeypot: string;
  startedAt: number;
  challengeId: string;
  taps: number[];
  inviteCode: string;
}): Promise<string> {
  await assertNotBlocked();
  const settings = await loadSettings();
  const ip = clientIp();

  if (settings.signupMode === "closed") {
    await logEvent("signup", "blocked", "signup_closed");
    throw new Error("cadastro fechado no momento");
  }

  if (input.honeypot.trim()) {
    await logEvent("signup", "blocked", "honeypot");
    throw new Error("não foi possível concluir o cadastro");
  }

  const elapsed = (Date.now() - input.startedAt) / 1000;
  if (!Number.isFinite(elapsed) || elapsed < settings.minFormSeconds) {
    await logEvent("signup", "blocked", "too_fast");
    throw new Error("calma — preencha o formulário com cuidado");
  }

  if (settings.signupMode === "invite_only" && !input.inviteCode.trim()) {
    await logEvent("signup", "blocked", "invite_required");
    throw new Error("cadastro só com convite neste momento");
  }

  const recent = await countSince("signup", ip, 1);
  if (recent >= settings.signupPerIpHour) {
    await logEvent("signup", "blocked", "rate_signup");
    throw new Error("muitos cadastros deste endereço — tente mais tarde");
  }

  await consumeChallenge(input.challengeId, input.taps);
  const ticket = await mintSignupTicket(input.inviteCode.trim() || null);
  await logEvent("signup", "allowed", null);
  return ticket;
}

export async function guardNewProfile(): Promise<void> {
  await assertNotBlocked();
  const ip = clientIp();
  const recent = await countSince("profile", ip, 1);
  if (recent >= 8) {
    await logEvent("profile", "blocked", "rate_profile");
    throw new Error("muitas contas deste endereço — tente mais tarde");
  }
  await logEvent("profile", "allowed", null);
}

export async function guardRequest(): Promise<void> {
  await assertNotBlocked();
  const settings = await loadSettings();
  const ip = clientIp();
  const recent = await countSince("request", ip, 1);
  if (recent >= settings.requestsPerHour) {
    await logEvent("request", "blocked", "rate_request");
    throw new Error("muitos pedidos — espere um pouco");
  }
  await logEvent("request", "allowed", null);
}

export async function checkLoginLock(email: string): Promise<{ locked: boolean; message?: string }> {
  await assertNotBlocked();
  const sql = await getSql();
  const ip = clientIp();
  const keys = [ip, email.toLowerCase().trim()];
  for (const key of keys) {
    const rows = await sql<{ fail_count: number; locked_until: string | null }>`
      select fail_count, locked_until from sinal_login_fails where fail_key = ${key} limit 1`;
    const row = rows[0];
    if (row?.locked_until && new Date(row.locked_until) > new Date()) {
      await logEvent("login", "blocked", "lockout");
      return { locked: true, message: "muitas tentativas — a entrada está travada por alguns minutos" };
    }
  }
  return { locked: false };
}

export async function recordLoginFail(email: string): Promise<void> {
  const settings = await loadSettings();
  const sql = await getSql();
  const keys = [clientIp(), email.toLowerCase().trim()];
  for (const key of keys) {
    const rows = await sql<{ fail_count: number }>`
      select fail_count from sinal_login_fails where fail_key = ${key} limit 1`;
    const next = (rows[0]?.fail_count ?? 0) + 1;
    const lock =
      next >= settings.loginMaxFails
        ? new Date(Date.now() + settings.loginLockoutMinutes * 60_000).toISOString()
        : null;
    await sql`insert into sinal_login_fails (fail_key, fail_count, locked_until, updated_at)
      values (${key}, ${next}, ${lock}, now())
      on conflict (fail_key) do update set
        fail_count = ${next},
        locked_until = ${lock},
        updated_at = now()`;
  }
  await logEvent("login", "blocked", "bad_credentials");
}

export async function clearLoginFails(email: string): Promise<void> {
  const sql = await getSql();
  const keys = [clientIp(), email.toLowerCase().trim()];
  for (const key of keys) {
    await sql`delete from sinal_login_fails where fail_key = ${key}`;
  }
  await logEvent("login", "allowed", null);
}

export type SpamEvent = {
  id: number;
  kind: string;
  ip: string;
  outcome: string;
  reason: string | null;
  detail: string | null;
  createdAt: string;
};

export async function listSpamEvents(limit = 40): Promise<SpamEvent[]> {
  const sql = await getSql();
  const rows = await sql<{
    id: number;
    kind: string;
    ip: string;
    outcome: string;
    reason: string | null;
    detail: string | null;
    created_at: string;
  }>`select id, kind, ip, outcome, reason, detail, created_at
     from sinal_spam_events order by created_at desc limit ${limit}`;
  return rows.map((r) => ({
    id: r.id,
    kind: r.kind,
    ip: r.ip,
    outcome: r.outcome,
    reason: r.reason,
    detail: r.detail,
    createdAt: r.created_at,
  }));
}

export async function spamStats(): Promise<{ blockedToday: number; allowedToday: number; blockedIps: number }> {
  const sql = await getSql();
  const blocked = await sql<{ n: number }>`
    select count(*)::int as n from sinal_spam_events
    where outcome = 'blocked' and created_at > date_trunc('day', now())`;
  const allowed = await sql<{ n: number }>`
    select count(*)::int as n from sinal_spam_events
    where outcome = 'allowed' and created_at > date_trunc('day', now())`;
  const ips = await sql<{ n: number }>`select count(*)::int as n from sinal_ip_blocks`;
  return {
    blockedToday: blocked[0]?.n ?? 0,
    allowedToday: allowed[0]?.n ?? 0,
    blockedIps: ips[0]?.n ?? 0,
  };
}

export async function listIpBlocks(): Promise<{ ip: string; reason: string | null; createdAt: string }[]> {
  const sql = await getSql();
  const rows = await sql<{ ip: string; reason: string | null; created_at: string }>`
    select ip, reason, created_at from sinal_ip_blocks order by created_at desc`;
  return rows.map((r) => ({ ip: r.ip, reason: r.reason, createdAt: r.created_at }));
}

export async function blockIp(ip: string, reason: string): Promise<void> {
  const sql = await getSql();
  const clean = ip.trim().slice(0, 64);
  if (!clean) throw new Error("informe um IP");
  await sql`insert into sinal_ip_blocks (ip, reason) values (${clean}, ${reason || "manual"})
    on conflict (ip) do update set reason = ${reason || "manual"}`;
}

export async function unblockIp(ip: string): Promise<void> {
  const sql = await getSql();
  await sql`delete from sinal_ip_blocks where ip = ${ip}`;
}
