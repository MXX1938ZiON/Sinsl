export const CATEGORY_DEFS = [
  { key: "filme", label: "Filmes" },
  { key: "serie", label: "Séries" },
  { key: "desenho", label: "Desenhos" },
  { key: "anime", label: "Animes" },
  { key: "dorama", label: "Doramas" },
  { key: "documentario", label: "Documentários" },
  { key: "ao-vivo", label: "Ao vivo" },
] as const;

export const GENRES = [
  { key: "acao", label: "Ação" },
  { key: "aventura", label: "Aventura" },
  { key: "fantasia", label: "Fantasia" },
  { key: "terror", label: "Terror" },
  { key: "drama", label: "Drama" },
  { key: "romance", label: "Romance" },
  { key: "ficcao-cientifica", label: "Ficção Científica" },
  { key: "comedia", label: "Comédia" },
  { key: "suspense", label: "Suspense" },
  { key: "sobrenatural", label: "Sobrenatural" },
] as const;

export const RATINGS: Record<string, { label: string; colorClass: string }> = {
  L: { label: "Livre", colorClass: "bg-rating-l text-bg" },
  "10": { label: "10 anos", colorClass: "bg-rating-10 text-bg" },
  "12": { label: "12 anos", colorClass: "bg-rating-12 text-bg" },
  "14": { label: "14 anos", colorClass: "bg-rating-14 text-bg" },
  "16": { label: "16 anos", colorClass: "bg-rating-16 text-fg" },
  "18": { label: "18 anos", colorClass: "bg-rating-18 text-fg" },
};

export const RATING_RANK: Record<string, number> = {
  L: 0,
  "10": 1,
  "12": 2,
  "14": 3,
  "16": 4,
  "18": 5,
};

export type Episode = { title: string; desc: string };

function demoEpisodes(n: number): Episode[] {
  return Array.from({ length: n }, (_, i) => ({
    title: `Episódio ${i + 1}`,
    desc: "Descrição breve do episódio — capa e resumo curto, no formato usado no Plex.",
  }));
}

export type CollectionItem = {
  title: string;
  desc: string;
  genres: string[];
  episodes?: Episode[];
};

export type Collection = {
  key: string;
  title: string;
  sub: string;
  items: CollectionItem[];
  spinoffs: { key: string; title: string; sub: string; items: CollectionItem[] }[];
};

export const COLLECTIONS: Collection[] = [
  {
    key: "harry-potter",
    title: "Harry Potter",
    sub: "Universo bruxo principal — 8 filmes.",
    items: [
      { title: "Harry Potter e a Pedra Filosofal", desc: "Um garoto órfão descobre que é bruxo e embarca para Hogwarts.", genres: ["fantasia", "aventura"] },
      { title: "Harry Potter e a Câmara Secreta", desc: "Um mistério antigo ameaça os alunos nascidos trouxas de Hogwarts.", genres: ["fantasia", "aventura"] },
      { title: "Harry Potter e o Prisioneiro de Azkaban", desc: "Um fugitivo perigoso se aproxima da escola, revelando segredos do passado.", genres: ["fantasia", "aventura"] },
      { title: "Harry Potter e o Cálice de Fogo", desc: "Harry é misteriosamente inscrito num torneio bruxo perigoso.", genres: ["fantasia", "aventura"] },
      { title: "Harry Potter e a Ordem da Fênix", desc: "Um grupo secreto de alunos se prepara pra resistir a uma ameaça crescente.", genres: ["fantasia", "drama"] },
      { title: "Harry Potter e o Enigma do Príncipe", desc: "Segredos do passado do vilão principal vêm à tona.", genres: ["fantasia", "drama"] },
      { title: "Harry Potter e as Relíquias da Morte – Parte 1", desc: "Os heróis partem em busca de objetos capazes de deter o mal.", genres: ["fantasia", "aventura"] },
      { title: "Harry Potter e as Relíquias da Morte – Parte 2", desc: "O confronto final decide o destino do mundo bruxo.", genres: ["fantasia", "acao"] },
    ],
    spinoffs: [
      {
        key: "animais-fantasticos",
        title: "Animais Fantásticos",
        sub: "Décadas antes, em Nova York e Europa.",
        items: [
          { title: "Animais Fantásticos e Onde Habitam", desc: "Um magizoologista perde criaturas mágicas numa Nova York dos anos 1920.", genres: ["fantasia", "aventura"] },
          { title: "Animais Fantásticos: Os Crimes de Grindelwald", desc: "Um bruxo das trevas reúne seguidores enquanto o passado é revisitado.", genres: ["fantasia", "drama"] },
          { title: "Animais Fantásticos: Os Segredos de Dumbledore", desc: "Um plano se forma pra deter o avanço de um bruxo ambicioso.", genres: ["fantasia", "aventura"] },
        ],
      },
    ],
  },
  {
    key: "vampire-diaries",
    title: "The Vampire Diaries",
    sub: "Mystic Falls, segredos sobrenaturais.",
    items: [
      { title: "Temporada 1", desc: "Uma adolescente se envolve com um vampiro centenário numa cidade cheia de segredos.", genres: ["sobrenatural", "romance"], episodes: demoEpisodes(4) },
      { title: "Temporada 2", desc: "Um vampiro original chega à cidade atrás de algo que só Mystic Falls pode oferecer.", genres: ["sobrenatural", "drama"], episodes: demoEpisodes(4) },
      { title: "Temporada 3", desc: "O passado da família fundadora de vampiros começa a se revelar.", genres: ["sobrenatural", "drama"], episodes: demoEpisodes(4) },
      { title: "Temporada 4", desc: "A transição pra uma nova condição sobrenatural muda tudo pra protagonista.", genres: ["sobrenatural", "drama"], episodes: demoEpisodes(4) },
    ],
    spinoffs: [
      {
        key: "the-originals",
        title: "The Originals",
        sub: "Nova Orleans, a família de vampiros mais antiga.",
        items: [
          { title: "Temporada 1", desc: "Um vampiro original retorna a Nova Orleans e encontra a cidade em guerra por poder.", genres: ["sobrenatural", "drama"], episodes: demoEpisodes(4) },
          { title: "Temporada 2", desc: "Alianças frágeis entre vampiros, bruxos e lobisomens ameaçam desmoronar.", genres: ["sobrenatural", "drama"], episodes: demoEpisodes(4) },
        ],
      },
    ],
  },
];

export type CatalogTitle = {
  id: string;
  title: string;
  category: string;
  genres: string[];
  ageRating: string | null;
  dubbed: boolean;
  synopsis: string | null;
  poster: string | null;
  posterCredit: string | null;
  views: number;
  addedAt: string;
  source: string;
  youtubeId: string | null;
  hlsUrl: string | null;
  telegramUrl: string | null;
  hasStream: boolean;
  locked: boolean;
  avgRating: number | null;
  ratingCount: number;
  myRating: number | null;
  resumePct: number | null;
};

export type SinalProfile = {
  userId: string;
  username: string;
  role: "admin" | "user" | "trial";
  status: "active" | "disabled";
  unlockedUntil: string | null;
  unlockedForever: boolean;
  restrictionsCategories: string[];
  restrictionsGenres: string[];
  maxAgeRating: string | null;
  hasAccess: boolean;
  createdAt: string;
};
