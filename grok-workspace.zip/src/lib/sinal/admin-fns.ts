import { randomBytes } from "node:crypto";
import { createServerFn } from "@tanstack/react-start";
import { getSql } from "@/lib/db";
import { authMiddleware } from "@/lib/auth/middleware";
import {
  getProfile,
  listProfiles,
  loadSettings,
  saveSettings,
  type Settings,
  type TitleRow,
} from "./db.server";
import {
  blockIp,
  listIpBlocks,
  listSpamEvents,
  spamStats,
  unblockIp,
} from "./spam.server";
import { extractYouTubeId, parseM3u, telegramEmbedUrl } from "./media";
import { enqueueEmail, notifyTelegram, userMail } from "./emails.server";

async function requireAdmin(userId: string) {
  const profile = await getProfile(userId);
  if (!profile || profile.role !== "admin") throw new Error("sem permissão");
  return profile;
}

export const adminBootstrap = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const settings = await loadSettings();
    const users = await listProfiles();
    const stats = await spamStats();
    const events = await listSpamEvents(30);
    const blocks = await listIpBlocks();
    const titles = await sql<TitleRow>`select * from sinal_titles order by added_at desc`;
    const invites = await sql<{
      code: string;
      mode: string;
      days: number | null;
      used_by: string | null;
      created_at: string;
    }>`select code, mode, days, used_by, created_at from sinal_invites order by created_at desc`;
    const requests = await sql<{ id: number; body: string; user_id: string | null; created_at: string }>`
      select id, body, user_id, created_at from sinal_requests order by created_at desc limit 30`;
    const emails = await sql<{
      id: number;
      to_email: string;
      template: string;
      subject: string;
      status: string;
      created_at: string;
    }>`select id, to_email, template, subject, status, created_at from sinal_emails order by created_at desc limit 40`;
    const maint = await sql<{ mode: string; message: string }>`select mode, message from sinal_maintenance where id = 1`;
    const keys = await sql<{ key: string; value: string }>`
      select key, value from sinal_settings where key in ('telegram_bot_token','telegram_chat_id','resend_api_key')`;
    const keymap = Object.fromEntries(keys.map((k) => [k.key, k.value]));
    const mask = (v?: string) => (v && v.length > 6 ? `${v.slice(0, 4)}…${v.slice(-2)}` : v ? "definido" : "");
    const totalViews = titles.reduce((s, t) => s + (Number(t.views) || 0), 0);
    const activeSubs = users.filter((u) => u.hasAccess && u.role !== "admin").length;
    const top = [...titles].sort((a, b) => (b.views || 0) - (a.views || 0)).slice(0, 5);
    const chats = await sql<{ n: number }>`select count(*)::int as n from sinal_assistant_messages`;
    return {
      settings,
      stats,
      events,
      blocks,
      users,
      titles: titles.map((t) => ({
        id: t.id,
        title: t.title,
        category: t.category,
        source: t.source,
        views: t.views,
      })),
      invites,
      requests,
      emails,
      maintenance: maint[0] ?? { mode: "none", message: "" },
      telegramConfigured: Boolean(keymap.telegram_bot_token && keymap.telegram_chat_id),
      telegramTokenMasked: mask(keymap.telegram_bot_token),
      telegramChatId: keymap.telegram_chat_id || "",
      resendConfigured: Boolean(keymap.resend_api_key),
      dashboard: {
        users: users.length,
        activeSubs,
        titles: titles.length,
        views: totalViews,
        assistantMessages: chats[0]?.n ?? 0,
        top: top.map((t) => ({ title: t.title, views: t.views })),
      },
    };
  });

export const adminSaveSpamSettings = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((patch: Partial<Settings>) => patch)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    return saveSettings(data);
  });

export const adminBlockIp = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { ip: string; reason: string }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    await blockIp(data.ip, data.reason);
    return { ok: true };
  });

export const adminUnblockIp = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((ip: string) => ip)
  .handler(async ({ context, data: ip }) => {
    await requireAdmin(context.userId);
    await unblockIp(ip);
    return { ok: true };
  });

export const adminToggleUser = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((userId: string) => userId)
  .handler(async ({ context, data: userId }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const rows = await sql<{ status: string }>`select status from sinal_profiles where user_id = ${userId}`;
    if (!rows[0]) throw new Error("usuário não encontrado");
    const next = rows[0].status === "active" ? "disabled" : "active";
    await sql`update sinal_profiles set status = ${next} where user_id = ${userId}`;
    return { ok: true };
  });

export const adminGrantAccess = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; mode: "forever" | "days" | "revoke"; days?: number }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    if (data.mode === "forever") {
      await sql`update sinal_profiles set unlocked_forever = true, unlocked_until = null where user_id = ${data.userId}`;
    } else if (data.mode === "revoke") {
      await sql`update sinal_profiles set unlocked_forever = false, unlocked_until = null where user_id = ${data.userId}`;
    } else {
      const days = Math.max(1, data.days ?? 7);
      const until = new Date(Date.now() + days * 86400000).toISOString();
      await sql`update sinal_profiles set unlocked_forever = false, unlocked_until = ${until} where user_id = ${data.userId}`;
    }
    return { ok: true };
  });

export const adminSaveRestrictions = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (input: {
      userId: string;
      categories: string[];
      genres: string[];
      maxAgeRating: string | null;
    }) => input,
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    await sql`update sinal_profiles set
      restrictions_categories = ${JSON.stringify(data.categories)},
      restrictions_genres = ${JSON.stringify(data.genres)},
      max_age_rating = ${data.maxAgeRating}
      where user_id = ${data.userId}`;
    return { ok: true };
  });

export const adminCreateInvite = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { mode: "permanent" | "temporary"; days: number }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const part = () => randomBytes(3).toString("hex").toUpperCase();
    const code = `SNL-${part()}-${part()}`;
    const sql = await getSql();
    await sql`insert into sinal_invites (code, mode, days) values (${code}, ${data.mode}, ${data.mode === "temporary" ? data.days : null})`;
    return { code };
  });

export const adminMaintenance = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { mode: "none" | "scheduled" | "active"; message: string }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    await sql`update sinal_maintenance set mode = ${data.mode}, message = ${data.message} where id = 1`;
    return { ok: true };
  });

export const adminAddYoutube = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { url: string; title: string; category: string }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const youtubeId = extractYouTubeId(data.url);
    if (!youtubeId) throw new Error("não reconheci essa URL do YouTube");
    const id = `yt-${youtubeId}`;
    const sql = await getSql();
    await sql`insert into sinal_titles (id, title, category, genres, poster, source, youtube_id)
      values (${id}, ${data.title.trim()}, ${data.category}, '[]', ${`https://img.youtube.com/vi/${youtubeId}/hqdefault.jpg`}, 'youtube', ${youtubeId})
      on conflict (id) do update set title = ${data.title.trim()}`;
    return { id };
  });

export const adminAddIptv = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { title: string; hlsUrl: string }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    if (!/^https?:\/\//i.test(data.hlsUrl)) throw new Error("informe uma URL HLS (m3u8)");
    const id = `iptv-${randomBytes(4).toString("hex")}`;
    const sql = await getSql();
    await sql`insert into sinal_titles (id, title, category, genres, source, hls_url, age_rating)
      values (${id}, ${data.title.trim()}, 'ao-vivo', '[]', 'iptv', ${data.hlsUrl.trim()}, 'L')`;
    return { id };
  });

export const adminImportM3u = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((text: string) => text)
  .handler(async ({ context, data: text }) => {
    await requireAdmin(context.userId);
    const channels = parseM3u(text);
    if (!channels.length) throw new Error("nenhum canal encontrado nessa lista");
    const sql = await getSql();
    let added = 0;
    for (const ch of channels) {
      const id = `iptv-${randomBytes(4).toString("hex")}`;
      await sql`insert into sinal_titles (id, title, category, genres, source, hls_url, age_rating)
        values (${id}, ${ch.title}, 'ao-vivo', '[]', 'iptv', ${ch.url}, 'L')`;
      added += 1;
    }
    return { added };
  });

export const adminAddTelegram = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { title: string; url: string }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    if (!telegramEmbedUrl(data.url)) throw new Error("cole um post público t.me/canal/123");
    const id = `tg-${randomBytes(4).toString("hex")}`;
    const sql = await getSql();
    await sql`insert into sinal_titles (id, title, category, genres, source, telegram_url, age_rating)
      values (${id}, ${data.title.trim()}, 'filme', '[]', 'telegram', ${data.url.trim()}, 'L')`;
    return { id };
  });

export const adminSaveIntegrations = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator(
    (input: { telegramBotToken: string; telegramChatId: string; resendApiKey: string }) => input,
  )
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const entries: [string, string][] = [
      ["telegram_bot_token", data.telegramBotToken.trim()],
      ["telegram_chat_id", data.telegramChatId.trim()],
      ["resend_api_key", data.resendApiKey.trim()],
    ];
    for (const [key, value] of entries) {
      if (!value) continue;
      await sql`insert into sinal_settings (key, value) values (${key}, ${value})
        on conflict (key) do update set value = ${value}`;
    }
    return { ok: true };
  });

export const adminTestTelegram = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    await notifyTelegram("Sinal: teste de integração Telegram. Se você leu isto, o bot está no ar.");
    return { ok: true };
  });

export const adminSendEmail = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { userId: string; template: "welcome" | "subscribed" | "receipt" | "billing" }) => input)
  .handler(async ({ context, data }) => {
    await requireAdmin(context.userId);
    const profile = await getProfile(data.userId);
    const mail = await userMail(data.userId);
    if (!profile || !mail?.email) throw new Error("usuário sem e-mail");
    await enqueueEmail({
      userId: data.userId,
      toEmail: mail.email,
      template: data.template,
      ctx: {
        name: profile.username,
        until: profile.unlockedUntil
          ? new Date(profile.unlockedUntil).toLocaleDateString("pt-BR")
          : undefined,
      },
    });
    return { ok: true };
  });

export const adminAssistantLog = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    return sql<{
      user_id: string;
      mode: string;
      role: string;
      content: string;
      created_at: string;
    }>`select user_id, mode, role, content, created_at
       from sinal_assistant_messages order by created_at desc limit 50`;
  });
