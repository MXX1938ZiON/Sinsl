import { Link } from "@tanstack/react-router";
import Hls from "hls.js";
import { Maximize, Pause, Play, Volume2, VolumeX } from "lucide-react";
import { useEffect, useRef, useState } from "react";
import { getPlayback, getProgress, saveProgress, type Playback } from "@/lib/sinal/fns";

declare global {
  interface Window {
    WebTorrent?: new () => {
      add: (magnet: string, cb: (t: TorrentLike) => void) => void;
    };
  }
}

type TorrentLike = {
  files: { name: string; length: number; offset: number; renderTo: (el: HTMLVideoElement, opts: { autoplay: boolean }) => void }[];
  numPeers: number;
  downloadSpeed: number;
  uploadSpeed: number;
  pieceLength: number;
  select: (a: number, b: number, p: boolean) => void;
  deselect: (a: number, b: number, p: boolean) => void;
  destroy: () => void;
};

function loadWebTorrent(): Promise<NonNullable<Window["WebTorrent"]>> {
  if (window.WebTorrent) return Promise.resolve(window.WebTorrent);
  return new Promise((resolve, reject) => {
    const s = document.createElement("script");
    s.src = "https://cdn.jsdelivr.net/npm/webtorrent@2.6.8/dist/webtorrent.min.js";
    s.onload = () => {
      if (window.WebTorrent) resolve(window.WebTorrent);
      else reject(new Error("WebTorrent não carregou"));
    };
    s.onerror = () => reject(new Error("WebTorrent não carregou"));
    document.head.appendChild(s);
  });
}

function fmtTime(sec: number) {
  if (!isFinite(sec) || sec < 0) return "0:00";
  const m = Math.floor(sec / 60);
  const s = Math.floor(sec % 60).toString().padStart(2, "0");
  return `${m}:${s}`;
}

function fmtSpeed(bps: number) {
  const kb = bps / 1024;
  return kb < 1024 ? `${kb.toFixed(0)} KB/s` : `${(kb / 1024).toFixed(1)} MB/s`;
}

export function SinalPlayer({ id, title }: { id: string; title: string }) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const cinemaRef = useRef<HTMLDivElement>(null);
  const [playback, setPlayback] = useState<Playback | null>(null);
  const [error, setError] = useState("");
  const [paused, setPaused] = useState(true);
  const [muted, setMuted] = useState(false);
  const [status, setStatus] = useState("conectando…");
  const [peers, setPeers] = useState("");
  const [progress, setProgress] = useState(0);
  const [buffered, setBuffered] = useState(0);
  const [current, setCurrent] = useState(0);
  const [duration, setDuration] = useState(0);
  const [showUi, setShowUi] = useState(true);

  useEffect(() => {
    let dead = false;
    void getPlayback({ data: id })
      .then((p) => {
        if (!dead) setPlayback(p);
      })
      .catch((err: unknown) => {
        if (!dead) setError(err instanceof Error ? err.message : "não foi possível tocar");
      });
    return () => {
      dead = true;
    };
  }, [id]);

  useEffect(() => {
    const video = videoRef.current;
    if (!video || !playback) return;
    if (playback.kind === "youtube" || playback.kind === "telegram") return;

    let hls: Hls | null = null;
    let torrent: TorrentLike | null = null;
    let statsTimer: number | undefined;
    let progressTimer: number | undefined;

    async function start() {
      if (playback.kind === "hls") {
        setStatus("ao vivo · HLS");
        if (Hls.isSupported()) {
          hls = new Hls();
          hls.loadSource(playback.hlsUrl);
          hls.attachMedia(video!);
          hls.on(Hls.Events.MANIFEST_PARSED, () => {
            void video!.play().catch(() => {});
          });
        } else if (video!.canPlayType("application/vnd.apple.mpegurl")) {
          video!.src = playback.hlsUrl;
          void video!.play().catch(() => {});
        } else {
          setError("este navegador não toca HLS");
        }
        return;
      }

      if (playback.kind === "magnet") {
        setStatus("conectando ao swarm…");
        const WT = await loadWebTorrent();
        const client = new WT();
        client.add(playback.magnet, (t) => {
          torrent = t;
          const file = t.files
            .filter((f) => /\.(mp4|webm|m4v)$/i.test(f.name))
            .sort((a, b) => b.length - a.length)[0];
          if (!file) {
            setStatus("arquivo não encontrado");
            return;
          }
          file.renderTo(video!, { autoplay: true });
          void video!.play().catch(() => {});
          statsTimer = window.setInterval(() => {
            setPeers(`${t.numPeers} peer${t.numPeers === 1 ? "" : "s"}`);
            setStatus(`${fmtSpeed(t.downloadSpeed)} baixando · ${fmtSpeed(t.uploadSpeed)} enviando`);
          }, 1000);
        });
      }
    }

    void start();

    const onMeta = () => {
      setDuration(video.duration || 0);
      void getProgress({ data: id }).then((saved) => {
        if (saved && saved.seconds > 5 && saved.seconds / saved.duration < 0.95) {
          video.currentTime = saved.seconds;
          setStatus(`retomando de ${fmtTime(saved.seconds)}`);
        }
      });
    };
    const onTime = () => {
      setCurrent(video.currentTime);
      if (video.duration) setProgress((video.currentTime / video.duration) * 100);
    };
    const onProg = () => {
      if (video.buffered.length && video.duration) {
        setBuffered((video.buffered.end(video.buffered.length - 1) / video.duration) * 100);
      }
    };
    const onPlay = () => {
      setPaused(false);
      progressTimer = window.setInterval(() => {
        void saveProgress({
          data: { titleId: id, seconds: video.currentTime, duration: video.duration || 0 },
        });
      }, 10_000);
    };
    const onPause = () => {
      setPaused(true);
      if (progressTimer) window.clearInterval(progressTimer);
      void saveProgress({
        data: { titleId: id, seconds: video.currentTime, duration: video.duration || 0 },
      });
    };

    video.addEventListener("loadedmetadata", onMeta);
    video.addEventListener("timeupdate", onTime);
    video.addEventListener("progress", onProg);
    video.addEventListener("play", onPlay);
    video.addEventListener("pause", onPause);

    return () => {
      video.removeEventListener("loadedmetadata", onMeta);
      video.removeEventListener("timeupdate", onTime);
      video.removeEventListener("progress", onProg);
      video.removeEventListener("play", onPlay);
      video.removeEventListener("pause", onPause);
      if (statsTimer) window.clearInterval(statsTimer);
      if (progressTimer) window.clearInterval(progressTimer);
      hls?.destroy();
      torrent?.destroy();
      video.pause();
      video.removeAttribute("src");
      video.load();
    };
  }, [playback, id]);

  if (error) {
    return (
      <main className="mx-auto max-w-3xl px-6 py-10">
        <Link to="/titulo/$id" params={{ id }} className="text-sm text-muted hover:text-fg">
          ← voltar
        </Link>
        <p className="mt-6 text-danger">{error}</p>
        {error.includes("assinatura") ? (
          <Link to="/conta" className="mt-4 inline-block text-signal underline">
            Ir para Minha conta
          </Link>
        ) : null}
      </main>
    );
  }

  if (playback?.kind === "youtube") {
    return (
      <main className="mx-auto max-w-5xl px-6 py-8">
        <Link to="/titulo/$id" params={{ id }} className="text-sm text-muted hover:text-fg">
          ← voltar
        </Link>
        <h1 className="mt-4 mb-4 font-display text-xl font-semibold">{title}</h1>
        <div className="relative aspect-video overflow-hidden rounded-lg bg-cinema shadow-2xl">
          <iframe
            className="absolute inset-0 h-full w-full"
            src={`https://www.youtube.com/embed/${playback.youtubeId}?autoplay=1&rel=0`}
            allow="autoplay; encrypted-media"
            allowFullScreen
            title={title}
          />
        </div>
      </main>
    );
  }

  if (playback?.kind === "telegram") {
    return (
      <main className="mx-auto max-w-5xl px-6 py-8">
        <Link to="/titulo/$id" params={{ id }} className="text-sm text-muted hover:text-fg">
          ← voltar
        </Link>
        <h1 className="mt-4 mb-4 font-display text-xl font-semibold">{title}</h1>
        <div className="overflow-hidden rounded-lg border border-border bg-cinema">
          <iframe
            className="min-h-125 w-full"
            src={playback.embedUrl}
            title={title}
          />
        </div>
        <p className="mt-3 text-xs text-muted">
          Conteúdo via Telegram. Controles e marca deles aparecem no embed oficial.
        </p>
      </main>
    );
  }

  return (
    <main className="mx-auto max-w-5xl px-4 py-6 sm:px-6">
      <Link to="/titulo/$id" params={{ id }} className="text-sm text-muted hover:text-fg">
        ← voltar
      </Link>
      <div
        ref={cinemaRef}
        className="relative mt-4 overflow-hidden rounded-lg bg-cinema shadow-2xl"
        onMouseMove={() => setShowUi(true)}
      >
        <video ref={videoRef} className="block max-h-[74vh] w-full bg-cinema" playsInline />
        {paused ? (
          <button
            type="button"
            className="absolute top-1/2 left-1/2 grid size-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full border border-fg/20 bg-bg/55 text-fg backdrop-blur-sm"
            onClick={() => void videoRef.current?.play()}
            aria-label="play"
          >
            <Play className="size-6 fill-current" />
          </button>
        ) : null}
        <div
          className={`absolute inset-x-0 bottom-0 bg-linear-to-t from-cinema to-transparent px-4 pt-10 pb-3 transition-opacity ${showUi ? "opacity-100" : "opacity-0"}`}
        >
          <div className="mb-2 flex items-center gap-2.5">
            <span className="w-8 text-center text-[11px] text-muted tabular-nums">{fmtTime(current)}</span>
            <div className="relative h-3.5 flex-1">
              <div className="absolute top-1/2 left-0 h-1 w-full -translate-y-1/2 rounded-full bg-fg/15" />
              <div
                className="absolute top-1/2 left-0 h-1 -translate-y-1/2 rounded-full bg-signal/30"
                style={{ width: `${buffered}%` }}
              />
              <input
                type="range"
                min={0}
                max={100}
                value={progress}
                onChange={(e) => {
                  const v = videoRef.current;
                  if (v?.duration) v.currentTime = (Number(e.target.value) / 100) * v.duration;
                }}
                className="relative z-2 w-full accent-signal"
              />
            </div>
            <span className="w-8 text-center text-[11px] text-muted tabular-nums">{fmtTime(duration)}</span>
          </div>
          <div className="flex items-center gap-3 text-fg">
            <button
              type="button"
              onClick={() => {
                const v = videoRef.current;
                if (!v) return;
                if (v.paused) void v.play();
                else v.pause();
              }}
              aria-label="playpause"
            >
              {paused ? <Play className="size-5" /> : <Pause className="size-5" />}
            </button>
            <button
              type="button"
              onClick={() => {
                const v = videoRef.current;
                if (!v) return;
                v.muted = !v.muted;
                setMuted(v.muted);
              }}
              aria-label="mute"
            >
              {muted ? <VolumeX className="size-5" /> : <Volume2 className="size-5" />}
            </button>
            <div className="flex-1 text-xs text-muted">
              <p className="font-display text-sm text-fg">{title}</p>
              <p>
                {peers} {status}
              </p>
            </div>
            <button
              type="button"
              onClick={() => {
                const el = cinemaRef.current;
                if (!el) return;
                if (document.fullscreenElement) void document.exitFullscreen();
                else void el.requestFullscreen();
              }}
              aria-label="tela cheia"
            >
              <Maximize className="size-5" />
            </button>
          </div>
        </div>
      </div>
    </main>
  );
}
