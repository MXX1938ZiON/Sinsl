const REAL_POSTERS = [
  "https://commons.wikimedia.org/wiki/Special:FilePath/Big_buck_bunny_poster_big.jpg",
  "https://commons.wikimedia.org/wiki/Special:FilePath/Sintel_poster.jpg",
];

const TONES = [
  "linear-gradient(160deg, #2a2419, #0f0d0b)",
  "linear-gradient(160deg, #241f1a, #0a0906)",
  "linear-gradient(160deg, #2f2416, #0f0d0b)",
  "linear-gradient(160deg, #1e2620, #0d100e)",
  "linear-gradient(160deg, #26221d, #0f0d0b)",
];

export function CinemaBg() {
  return (
    <>
      <div className="cinema-mosaic" aria-hidden="true">
        {Array.from({ length: 90 }, (_, i) => (
          <div
            key={i}
            className="aspect-2/3 overflow-hidden rounded-xs bg-surface"
            style={i % 9 === 0 ? undefined : { background: TONES[i % TONES.length] }}
          >
            {i % 9 === 0 ? (
              <img
                src={REAL_POSTERS[(i / 9) % REAL_POSTERS.length | 0]}
                alt=""
                className="h-full w-full object-cover"
                loading="lazy"
              />
            ) : null}
          </div>
        ))}
      </div>
      <div className="sinal-wash pointer-events-none fixed inset-0 z-[-2]" />
      <div className="sinal-grain pointer-events-none fixed inset-0 z-[-1]" />
    </>
  );
}
