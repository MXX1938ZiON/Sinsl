import { useCallback, useEffect, useState } from "react";
import { fetchChallenge } from "@/lib/sinal/fns";
import { cn } from "@/lib/utils";

const HEIGHTS = ["h-3", "h-5", "h-8", "h-5", "h-3"];

export type ChallengeValue = { challengeId: string; taps: number[] };

export function SignalChallenge({
  onChange,
}: {
  onChange: (value: ChallengeValue | null) => void;
}) {
  const [id, setId] = useState<string | null>(null);
  const [pattern, setPattern] = useState<number[]>([]);
  const [lit, setLit] = useState<number | null>(null);
  const [phase, setPhase] = useState<"load" | "show" | "input" | "ok" | "bad">("load");
  const [taps, setTaps] = useState<number[]>([]);
  const [error, setError] = useState("");

  const load = useCallback(async () => {
    setPhase("load");
    setTaps([]);
    setError("");
    onChange(null);
    try {
      const ch = await fetchChallenge();
      setId(ch.id);
      setPattern(ch.pattern);
      setPhase("show");
      for (let i = 0; i < ch.pattern.length; i++) {
        await new Promise((r) => setTimeout(r, 280));
        setLit(ch.pattern[i] ?? null);
        await new Promise((r) => setTimeout(r, 380));
        setLit(null);
      }
      setPhase("input");
    } catch (err) {
      setError(err instanceof Error ? err.message : "não foi possível sintonizar");
      setPhase("bad");
    }
  }, [onChange]);

  useEffect(() => {
    void load();
  }, [load]);

  function tap(i: number) {
    if (phase !== "input" || !id) return;
    const next = [...taps, i];
    setTaps(next);
    setLit(i);
    setTimeout(() => setLit(null), 180);
    if (next.length === pattern.length) {
      const ok = next.every((n, idx) => n === pattern[idx]);
      if (ok) {
        setPhase("ok");
        onChange({ challengeId: id, taps: next });
      } else {
        setPhase("bad");
        onChange(null);
        setTimeout(() => void load(), 700);
      }
    }
  }

  return (
    <div className="rounded-lg border border-border bg-bg p-4">
      <p className="font-display text-base font-semibold text-fg">Prova de sinal</p>
      <p className="mt-1 text-sm leading-normal text-muted">
        {phase === "show" && "Observe as barras — depois repita o ritmo."}
        {phase === "input" && "Sua vez: toque as barras na mesma ordem."}
        {phase === "ok" && "Sinal travado. Pode concluir o cadastro."}
        {phase === "load" && "Sintonizando…"}
        {phase === "bad" && (error || "Não bateu. Nova sequência.")}
      </p>
      <div className="mt-4 flex h-14 items-end justify-center gap-2">
        {HEIGHTS.map((h, i) => (
          <button
            key={i}
            type="button"
            aria-label={`barra ${i + 1}`}
            onClick={() => tap(i)}
            disabled={phase !== "input"}
            className={cn(
              "signal-bar w-2.5 rounded-sm transition-opacity",
              h,
              lit === i ? "opacity-100" : "opacity-35",
              phase === "ok" && "opacity-100",
            )}
          />
        ))}
      </div>
      <button
        type="button"
        className="mt-3 text-xs text-muted underline-offset-4 hover:text-fg hover:underline"
        onClick={() => void load()}
      >
        repetir sequência
      </button>
    </div>
  );
}
