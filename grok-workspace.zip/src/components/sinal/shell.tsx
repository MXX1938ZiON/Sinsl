import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import { Menu, Radio, Search, Send, X } from "lucide-react";
import { useEffect, useState, type FormEvent, type ReactNode } from "react";
import { SignedIn, SignedOut } from "@/lib/auth/gates";
import { signOut } from "@/lib/auth/client";
import { hasGateSessionMarker } from "@/lib/auth/gate-session-marker";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { GENRES } from "@/lib/sinal/catalog";
import {
  askAssistant,
  ensureMyProfile,
  getPublicConfig,
  listAssistantHistory,
  sendRequest,
  type SinalProfile,
} from "@/lib/sinal/fns";
import { cn } from "@/lib/utils";
import { CinemaBg } from "./cinema-bg";

const MODES = [
  { key: "suporte" as const, label: "Suporte" },
  { key: "vendas" as const, label: "Vendas" },
  { key: "tecnico" as const, label: "Técnico" },
];

export function SinalShell({ children }: { children: ReactNode }) {
  const { user, isPending } = useCurrentUserState();
  const [profile, setProfile] = useState<SinalProfile | null>(null);
  const [search, setSearch] = useState("");
  const [genreOpen, setGenreOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [reqOpen, setReqOpen] = useState(false);
  const [assistOpen, setAssistOpen] = useState(false);
  const [maintenance, setMaintenance] = useState({ mode: "none", message: "" });
  const navigate = useNavigate();
  const pathname = useRouterState({ select: (s) => s.location.pathname });

  useEffect(() => {
    void getPublicConfig().then((c) => setMaintenance(c.maintenance));
  }, []);

  useEffect(() => {
    if (!user) {
      setProfile(null);
      return;
    }
    void ensureMyProfile()
      .then(setProfile)
      .catch(() => setProfile(null));
  }, [user]);

  const isAdmin = profile?.role === "admin";
  const lockUsers = maintenance.mode === "active" && !isAdmin;

  return (
    <div className="relative min-h-screen bg-bg text-fg">
      <CinemaBg />
      {maintenance.mode === "scheduled" ? (
        <div className="bg-signal px-5 py-2.5 text-center text-sm font-medium text-bg">
          Manutenção programada{maintenance.message ? ` — ${maintenance.message}` : ""}
        </div>
      ) : null}

      <header className="relative flex flex-wrap items-center gap-3 border-b border-border px-4 py-4 sm:gap-6 sm:px-10">
        <Link to="/" className="font-display text-2xl font-semibold text-fg">
          Si<span className="text-signal">nal</span>
        </Link>
        <span className="hidden rounded-full border border-border px-2.5 py-1 text-xs text-muted sm:inline">
          0.0.25
        </span>
        <form
          className="order-last w-full sm:order-none sm:max-w-xs sm:flex-1"
          onSubmit={(e) => {
            e.preventDefault();
            void navigate({ to: "/", search: { q: search } });
          }}
        >
          <label className="relative block">
            <Search className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted" />
            <input
              className="w-full rounded-md border border-border bg-surface py-2.5 pr-3 pl-10 text-sm text-fg placeholder:text-muted"
              placeholder="Buscar no Sinal..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
            />
          </label>
        </form>
        <button
          type="button"
          className="ml-auto rounded-full border border-border p-2 text-muted sm:hidden"
          onClick={() => setMenuOpen((v) => !v)}
          aria-label="menu"
        >
          <Menu className="size-5" />
        </button>
        <nav
          className={cn(
            "flex w-full flex-wrap items-center gap-2 sm:ml-auto sm:w-auto",
            menuOpen ? "flex" : "hidden sm:flex",
          )}
        >
          <Link to="/" className={navCls(pathname === "/")}>
            Início
          </Link>
          <div className="relative">
            <button type="button" className={navCls(false)} onClick={() => setGenreOpen((v) => !v)}>
              Gênero
            </button>
            {genreOpen ? (
              <div className="absolute top-full left-0 z-20 mt-2 flex min-w-48 flex-col rounded-lg border border-border bg-surface p-1.5">
                {GENRES.map((g) => (
                  <Link
                    key={g.key}
                    to="/genero/$key"
                    params={{ key: g.key }}
                    className="rounded-sm px-3 py-2 text-left text-sm text-fg hover:bg-surface-hover"
                    onClick={() => setGenreOpen(false)}
                  >
                    {g.label}
                  </Link>
                ))}
              </div>
            ) : null}
          </div>
          <Link to="/ao-vivo" className={navCls(pathname.startsWith("/ao-vivo"))}>
            Ao vivo
          </Link>
          {isPending ? <div className="h-9 w-24 animate-pulse rounded-full bg-surface" /> : null}
          <SignedIn>
            {isAdmin ? (
              <Link to="/admin" className={navCls(pathname.startsWith("/admin"))}>
                Painel admin
              </Link>
            ) : (
              <Link to="/conta" className={navCls(pathname.startsWith("/conta"))}>
                Minha conta
              </Link>
            )}
            {!hasGateSessionMarker() ? (
              <button
                type="button"
                className={navCls(false)}
                onClick={() => void signOut("/")}
              >
                Sair{profile ? ` (${profile.username})` : ""}
              </button>
            ) : null}
          </SignedIn>
          <SignedOut>
            <Link to="/login" className={navCls(pathname === "/login")}>
              Login
            </Link>
            <Link to="/cadastro" className={navCls(pathname === "/cadastro")}>
              Cadastro
            </Link>
          </SignedOut>
          <button
            type="button"
            className="rounded-full border border-signal bg-signal px-4 py-2 text-sm font-medium text-bg"
            onClick={() => setReqOpen(true)}
          >
            Pedidos
          </button>
        </nav>
      </header>

      {lockUsers ? (
        <div className="fixed inset-0 z-50 grid place-items-center bg-bg p-10 text-center">
          <div>
            <h2 className="font-display text-2xl font-semibold">Em manutenção</h2>
            <p className="mt-2 max-w-md text-muted">{maintenance.message || "Voltamos em breve."}</p>
          </div>
        </div>
      ) : (
        children
      )}

      {reqOpen ? (
        <RequestsModal
          signedIn={Boolean(user)}
          onClose={() => setReqOpen(false)}
        />
      ) : null}

      <AssistantDock open={assistOpen} setOpen={setAssistOpen} signedIn={Boolean(user)} />
    </div>
  );
}

function navCls(active: boolean) {
  return cn(
    "rounded-full border px-4 py-2 text-sm",
    active
      ? "border-signal bg-signal text-bg"
      : "border-border text-muted hover:border-muted hover:text-fg",
  );
}

function RequestsModal({ signedIn, onClose }: { signedIn: boolean; onClose: () => void }) {
  const [text, setText] = useState("");
  const [note, setNote] = useState("");
  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    if (!signedIn) {
      setNote("entre na conta para enviar um pedido");
      return;
    }
    try {
      await sendRequest(text);
      setText("");
      setNote("pedido enviado");
    } catch (err) {
      setNote(err instanceof Error ? err.message : "falha");
    }
  }
  return (
    <div className="fixed inset-0 z-40 grid place-items-center bg-cinema/90 p-6" onClick={onClose}>
      <div
        className="relative w-full max-w-md rounded-lg border border-border bg-surface p-7"
        onClick={(e) => e.stopPropagation()}
      >
        <button type="button" className="absolute top-3.5 right-3.5 text-muted" onClick={onClose} aria-label="fechar">
          <X className="size-5" />
        </button>
        <h2 className="font-display text-xl font-semibold">Pedidos</h2>
        <p className="mt-1 mb-4 text-xs leading-normal text-muted">
          Diga o que falta no catálogo. Há limite por hora contra spam.
        </p>
        <form className="flex flex-col gap-2.5" onSubmit={onSubmit}>
          <input
            className="rounded-md border border-border bg-bg px-3 py-2.5 text-sm text-fg"
            placeholder="título, canal IPTV, post do Telegram…"
            value={text}
            onChange={(e) => setText(e.target.value)}
          />
          <button type="submit" className="rounded-md bg-signal py-2.5 text-sm font-medium text-bg">
            Enviar
          </button>
        </form>
        {note ? <p className="mt-2 text-xs text-muted">{note}</p> : null}
      </div>
    </div>
  );
}

function AssistantDock({
  open,
  setOpen,
  signedIn,
}: {
  open: boolean;
  setOpen: (v: boolean) => void;
  signedIn: boolean;
}) {
  const [mode, setMode] = useState<(typeof MODES)[number]["key"]>("suporte");
  const [input, setInput] = useState("");
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState("");
  const [messages, setMessages] = useState<{ role: string; content: string }[]>([]);

  useEffect(() => {
    if (!open || !signedIn) return;
    void listAssistantHistory({ data: mode }).then((rows) => setMessages(rows));
  }, [open, mode, signedIn]);

  async function send() {
    if (!signedIn) {
      setError("entre na conta para falar com o assistente");
      return;
    }
    const text = input.trim();
    if (!text) return;
    setInput("");
    setBusy(true);
    setError("");
    setMessages((m) => [...m, { role: "user", content: text }]);
    try {
      const res = await askAssistant({ data: { mode, message: text } });
      setMessages((m) => [...m, { role: "assistant", content: res.text }]);
    } catch (err) {
      setError(err instanceof Error ? err.message : "falha");
    } finally {
      setBusy(false);
    }
  }

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(!open)}
        className="fixed right-4 bottom-4 z-30 flex size-12 items-center justify-center rounded-full border border-border bg-surface text-signal shadow-lg"
        aria-label="assistente"
      >
        {open ? <X className="size-5" /> : <Radio className="size-5" />}
      </button>
      {open ? (
        <div className="fixed right-4 bottom-20 z-30 flex h-[min(28rem,70vh)] w-[min(22rem,calc(100vw-2rem))] flex-col rounded-xl border border-border bg-surface shadow-2xl">
          <div className="border-b border-border px-4 py-3">
            <p className="font-display font-semibold">Assistente Sinal</p>
            <p className="text-xs text-muted">Suporte, vendas e problemas técnicos</p>
            <div className="mt-2 flex gap-1">
              {MODES.map((m) => (
                <button
                  key={m.key}
                  type="button"
                  onClick={() => setMode(m.key)}
                  className={cn(
                    "rounded-full px-2.5 py-1 text-xs",
                    mode === m.key ? "bg-signal text-bg" : "border border-border text-muted",
                  )}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>
          <div className="flex-1 space-y-2 overflow-y-auto p-3 text-sm">
            {messages.length === 0 ? (
              <p className="text-muted">
                Pergunte sobre assinatura, player P2P, IPTV, Telegram ou o cadastro com prova de sinal.
              </p>
            ) : (
              messages.map((m, i) => (
                <div
                  key={i}
                  className={cn(
                    "rounded-md px-3 py-2 leading-normal",
                    m.role === "user" ? "bg-bg text-fg" : "bg-surface-hover text-fg",
                  )}
                >
                  {m.content}
                </div>
              ))
            )}
            {busy ? <p className="text-xs text-signal">sintonizando resposta…</p> : null}
            {error ? <p className="text-xs text-danger">{error}</p> : null}
          </div>
          <form
            className="flex gap-2 border-t border-border p-3"
            onSubmit={(e) => {
              e.preventDefault();
              void send();
            }}
          >
            <input
              className="min-w-0 flex-1 rounded-md border border-border bg-bg px-3 py-2 text-sm"
              placeholder="escreva aqui"
              value={input}
              onChange={(e) => setInput(e.target.value)}
            />
            <button type="submit" className="rounded-md bg-signal px-3 text-bg" aria-label="enviar" disabled={busy}>
              <Send className="size-4" />
            </button>
          </form>
        </div>
      ) : null}
    </>
  );
}
