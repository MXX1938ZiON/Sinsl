import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";
import type { CatalogTitle } from "@/lib/sinal/catalog";

export function PosterCard({
  item,
  rank,
  toPlayer,
}: {
  item: CatalogTitle | { placeholder: true; title: string };
  rank?: number;
  toPlayer?: boolean;
}) {
  const isPh = "placeholder" in item && item.placeholder;
  const inner = (
    <>
      <div className="poster-art relative flex aspect-2/3 items-end overflow-hidden rounded-xs border border-border bg-linear-to-br from-surface to-cinema p-2.5 text-sm text-muted transition-[border-color,transform] hover:border-accent hover:-translate-y-0.5">
        {rank ? (
          <span className="rank-stroke pointer-events-none absolute -bottom-3.5 -left-1.5 z-0 font-display text-7xl font-semibold leading-none">
            {rank}
          </span>
        ) : null}
        {!isPh && "poster" in item && item.poster ? (
          <img src={item.poster} alt="" className="absolute inset-0 z-0 h-full w-full object-cover" />
        ) : null}
        <span className="relative z-1 text-shadow-sm">
          {isPh || ("poster" in item && item.poster) ? "" : "title" in item ? item.title : ""}
        </span>
        {isPh ? (
          <span className="absolute top-2 right-2 z-1 rounded-full border border-border bg-surface-hover px-2 py-0.5 text-[10px] text-muted">
            em breve
          </span>
        ) : null}
        {!isPh && "resumePct" in item && item.resumePct != null ? (
          <div className="absolute inset-x-0 bottom-0 z-2 h-0.5 bg-cinema/40">
            <div className="h-full bg-signal" style={{ width: `${item.resumePct}%` }} />
          </div>
        ) : null}
      </div>
      <p className="mt-2.5 px-0.5 text-sm text-fg">{item.title}</p>
      {!isPh ? (
        <p className="px-0.5 text-[11px] text-muted">{toPlayer ? "continuar" : "ver ficha"}</p>
      ) : null}
    </>
  );

  if (isPh) {
    return (
      <div className="w-[150px] shrink-0 opacity-55">
        {inner}
      </div>
    );
  }

  const id = (item as CatalogTitle).id;
  return (
    <Link
      to={toPlayer ? "/player/$id" : "/titulo/$id"}
      params={{ id }}
      className={cn("w-[150px] shrink-0 text-left text-fg")}
    >
      {inner}
    </Link>
  );
}

export function padTo<T>(items: T[], n: number): (T | { placeholder: true; title: string })[] {
  const out: (T | { placeholder: true; title: string })[] = items.slice(0, n);
  while (out.length < n) out.push({ placeholder: true, title: "Em breve" });
  return out;
}
