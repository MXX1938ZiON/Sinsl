-- Sinal app schema (profiles, catalog, progress, spam lock)

create table if not exists sinal_profiles (
  user_id text primary key,
  username text not null unique,
  role text not null default 'user',
  status text not null default 'active',
  unlocked_until timestamptz,
  unlocked_forever boolean not null default false,
  restrictions_categories text not null default '[]',
  restrictions_genres text not null default '[]',
  max_age_rating text,
  trial_expires_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists sinal_titles (
  id text primary key,
  title text not null,
  category text not null,
  genres text not null default '[]',
  age_rating text,
  dubbed boolean not null default false,
  synopsis text,
  poster text,
  poster_credit text,
  views integer not null default 0,
  added_at timestamptz not null default now(),
  magnet text,
  youtube_id text,
  hls_url text,
  telegram_url text,
  source text not null default 'file'
);

create table if not exists sinal_progress (
  user_id text not null,
  title_id text not null,
  seconds real not null,
  duration real not null,
  updated_at timestamptz not null default now(),
  primary key (user_id, title_id)
);

create table if not exists sinal_ratings (
  user_id text not null,
  title_id text not null,
  stars integer not null,
  primary key (user_id, title_id)
);

create table if not exists sinal_invites (
  code text primary key,
  mode text not null,
  days integer,
  used_by text,
  used_at timestamptz,
  created_at timestamptz not null default now()
);

create table if not exists sinal_requests (
  id serial primary key,
  user_id text,
  body text not null,
  created_at timestamptz not null default now()
);

create table if not exists sinal_settings (
  key text primary key,
  value text not null
);

create table if not exists sinal_spam_events (
  id serial primary key,
  kind text not null,
  ip text not null,
  outcome text not null,
  reason text,
  detail text,
  created_at timestamptz not null default now()
);
create index if not exists sinal_spam_events_ip_idx on sinal_spam_events (ip, created_at);
create index if not exists sinal_spam_events_created_idx on sinal_spam_events (created_at);

create table if not exists sinal_ip_blocks (
  ip text primary key,
  reason text,
  created_at timestamptz not null default now()
);

create table if not exists sinal_login_fails (
  fail_key text primary key,
  fail_count integer not null default 0,
  locked_until timestamptz,
  updated_at timestamptz not null default now()
);

create table if not exists sinal_challenges (
  id text primary key,
  pattern text not null,
  expires_at timestamptz not null,
  used boolean not null default false
);

create table if not exists sinal_signup_tickets (
  ticket text primary key,
  expires_at timestamptz not null,
  used boolean not null default false,
  invite_code text
);

create table if not exists sinal_maintenance (
  id integer primary key default 1,
  mode text not null default 'none',
  message text not null default ''
);

insert into sinal_maintenance (id, mode, message)
  values (1, 'none', '')
  on conflict (id) do nothing;

insert into sinal_settings (key, value) values
  ('signup_mode', 'challenge'),
  ('signup_per_ip_hour', '3'),
  ('login_max_fails', '5'),
  ('login_lockout_minutes', '15'),
  ('requests_per_hour', '3'),
  ('min_form_seconds', '3')
on conflict (key) do nothing;

insert into sinal_titles (
  id, title, category, genres, age_rating, dubbed, synopsis, poster, poster_credit,
  views, added_at, magnet, source
) values (
  'bbb-demo',
  'Big Buck Bunny',
  'desenho',
  '["comedia","aventura"]',
  'L',
  false,
  'Um coelho gigante e pacato é provocado por três roedores valentões — até decidir que já teve paciência suficiente.',
  'https://commons.wikimedia.org/wiki/Special:FilePath/Big_buck_bunny_poster_big.jpg',
  'pôster: Blender Foundation, CC BY 3.0',
  3,
  '2026-09-01T10:00:00.000Z',
  $mag$magnet:?xt=urn:btih:dd8255ecdc7ca55fb0bbf81323d87062db1f6d1c&dn=Big+Buck+Bunny&tr=udp://explodie.org:6969&tr=udp://tracker.coppersurfer.tk:6969&tr=udp://tracker.empire-js.us:1337&tr=udp://tracker.leechers-paradise.org:6969&tr=udp://tracker.opentrackr.org:1337&tr=wss://tracker.btorrent.xyz&tr=wss://tracker.fastcast.nz&tr=wss://tracker.openwebtorrent.com&ws=https://webtorrent.io/torrents/big-buck-bunny/&xs=https://webtorrent.io/torrents/big-buck-bunny.torrent$mag$,
  'file'
), (
  'sintel-demo',
  'Sintel',
  'filme',
  '["fantasia","aventura"]',
  '10',
  false,
  'Uma jovem viajante atravessa terras geladas em busca de Scales, o dragão que criou e perdeu.',
  'https://commons.wikimedia.org/wiki/Special:FilePath/Sintel_poster.jpg',
  'pôster: Blender Foundation, CC BY 3.0',
  1,
  '2026-09-05T10:00:00.000Z',
  $mag$magnet:?xt=urn:btih:08ada5a7a6183aae1e09d831df6748d566095a10&dn=Sintel&tr=udp://explodie.org:6969&tr=udp://tracker.coppersurfer.tk:6969&tr=udp://tracker.empire-js.us:1337&tr=udp://tracker.leechers-paradise.org:6969&tr=udp://tracker.opentrackr.org:1337&tr=wss://tracker.btorrent.xyz&tr=wss://tracker.fastcast.nz&tr=wss://tracker.openwebtorrent.com$mag$,
  'file'
)
on conflict (id) do nothing;

create table if not exists sinal_emails (
  id serial primary key,
  user_id text,
  to_email text not null,
  template text not null,
  subject text not null,
  body text not null,
  status text not null default 'queued',
  error text,
  created_at timestamptz not null default now()
);

create table if not exists sinal_assistant_messages (
  id serial primary key,
  user_id text not null,
  mode text not null,
  role text not null,
  content text not null,
  created_at timestamptz not null default now()
);
create index if not exists sinal_assistant_user_idx on sinal_assistant_messages (user_id, created_at);

insert into sinal_titles (
  id, title, category, genres, age_rating, dubbed, synopsis, poster, poster_credit,
  views, added_at, hls_url, source
) values (
  'iptv-sinal-1',
  'Sinal Ao Vivo',
  'ao-vivo',
  '["documentario"]',
  'L',
  true,
  'Canal de demonstração IPTV (HLS público de teste). Serve para validar o player ao vivo — sem lista pirata.',
  null,
  null,
  8,
  '2026-09-20T10:00:00.000Z',
  'https://test-streams.mux.dev/x36xhzz/x36xhzz.m3u8',
  'iptv'
), (
  'iptv-sinal-2',
  'Sinal Extra',
  'ao-vivo',
  '["documentario"]',
  'L',
  true,
  'Segundo canal de teste HLS (Apple BipBop). Use o admin para importar sua própria lista M3U.',
  null,
  null,
  5,
  '2026-09-21T10:00:00.000Z',
  'https://devstreaming-cdn.apple.com/videos/streaming/examples/img_bipbop_adv_example_fmp4/master.m3u8',
  'iptv'
)
on conflict (id) do nothing;
